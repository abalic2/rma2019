package ba.unsa.etf.rma.fragmenti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.Adapter.RangListaAdapter;
import ba.unsa.etf.rma.Async.GetRequestAsync;
import ba.unsa.etf.rma.Async.PostRequestAsync;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Rang;
import ba.unsa.etf.rma.klase.RangListaKviza;
import ba.unsa.etf.rma.util.ConnectivityHelper;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.token;

public class RangLista extends Fragment {

    ArrayList<Rang> rangLista;
    RangListaKviza rangListaKviza;
    ListView rangListaLW;
    RangListaAdapter rangListaAdapter;

    String nazivKviza;
    String mojeIme;
    String mojProcenat;
    int pozicija = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_rang_lista, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        rangLista = new ArrayList<>();

        nazivKviza = (String) getArguments().getSerializable("Naziv");
        mojeIme = (String) getArguments().getSerializable("Igrac");
        mojProcenat = (String) getArguments().getSerializable("Tacnih");

        rangListaLW = getView().findViewById(R.id.rangLista);
        if (getContext() != null) rangListaAdapter = new RangListaAdapter(getContext(), rangLista);
        rangListaLW.setAdapter(rangListaAdapter);
        if (ConnectivityHelper.isNetworkAvailable(getContext())) {
            try {
                String responseRangLista = new GetRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Rangliste?access_token=" + token).get();
                parseRangLista(responseRangLista);
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext())
                    .setMessage("Zao nam je, ali internet konekcije nije dostupna")
                    .setPositiveButton("Uredu", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

            builder.show();
        }
    }

    public void parseRangLista(String response) {
        JSONObject rangListaObj;
        try {
            rangListaObj = new JSONObject(response);
            JSONArray docs = rangListaObj.getJSONArray("documents");
            for (int i = 0; i < docs.length(); i++) {
                JSONObject docsObj = new JSONObject(docs.getString(i));
                String idRangListe = docsObj.getString("name");
                String naziv = docsObj.getJSONObject("fields").getJSONObject("nazivKviza").getString("stringValue");
                if (naziv.contains(nazivKviza)) {
                    String listaKorisnika = docsObj.getJSONObject("fields").getJSONObject("lista").getJSONObject("mapValue").getString("fields");
                    String[] ai = listaKorisnika.substring(1, listaKorisnika.length() - 1).split(",");
                    for (int j = 0; j < ai.length; j++) {
                        JSONObject pozicijaObj = new JSONObject(ai[j].substring(ai[j].indexOf(":") + 1));

                        String field = pozicijaObj.getJSONObject("mapValue").getString("fields");
                        Log.w("FFFEEE", field);
                        String imeIgraca = field.substring(2, field.indexOf(":") - 1);
                        String procenatTacnih = new JSONObject(field.substring(field.indexOf(":") + 1)).getString("stringValue");
                        rangLista.add(new Rang(String.valueOf(j), imeIgraca, procenatTacnih));
                    }
                    pozicija = ai.length;
                    rangListaKviza = new RangListaKviza(naziv, rangLista);
                    rangLista.add(new Rang(String.valueOf(pozicija), mojeIme, mojProcenat));
                    //TODO path/tod err
                    //String data = "{\"fields\":{\"lista\":{\"mapValue\":{\"fields\":{\"" + (pozicija + 1) + "\":{\"mapValue\":{\"fields\":{\"" + mojeIme + "\":{\"stringValue\":\"" + mojProcenat + "\"}}}}}}}}}";
                    String data = "{\"fields\":{\"nazivKviza\":{\"stringValue\":\"" + nazivKviza + "\"},\"lista\":{\"mapValue\":{\"fields\":{\"" + (pozicija + 1) + "\":{\"mapValue\":{\"fields\":{\"" + mojeIme + "\":{\"stringValue\":\"" + mojProcenat + "\"}}}}}}}}}";
                    //String data = "{\"lista\":{\"mapValue\":{\"fields\":{\"" + (pozicija + 1) + "\":{\"mapValue\":{\"fields\":{\"" + mojeIme + "\":{\"stringValue\":\"" + mojProcenat + "\"}}}}}}}}";

                    new PostRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Rangliste?documentId=" + idRangListe + "?access_token=" + token, data, "POST");

                    Collections.sort(rangLista, new Comparator<Rang>() {
                        @Override
                        public int compare(Rang o1, Rang o2) {
                            return (Double.valueOf(o2.getProcenatTacnih())).compareTo(Double.valueOf(o1.getProcenatTacnih()));
                        }
                    });
                    rangListaAdapter.notifyDataSetChanged();
                    break;
                }
            }

        } catch (JSONException e) {
            Log.w("RL IOE", "RangLista IOe: " + e.getMessage());
            e.printStackTrace();
        }

    }
}
