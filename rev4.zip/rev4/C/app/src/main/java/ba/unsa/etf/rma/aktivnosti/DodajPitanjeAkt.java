package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.Async.PostRequestAsync;
import ba.unsa.etf.rma.Data.Data;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.token;

public class DodajPitanjeAkt extends AppCompatActivity {

    Pitanje pitanje;
    ArrayAdapter arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);

        final EditText editTextNaziv = findViewById(R.id.etNaziv);
        final ListView listView = findViewById(R.id.lvOdgovori);
        final EditText editTextOdgovor = findViewById(R.id.etOdgovor);
        Button buttonDodaj = findViewById(R.id.btnDodajOdgovor);
        final Button buttonDodajTacan = findViewById(R.id.btnDodajTacan);
        Button buttonDodajPitanje = findViewById(R.id.btnDodajPitanje);

        pitanje = new Pitanje();

        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, pitanje.getOdgovori());
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (pitanje.getTacan().equals(pitanje.getOdgovori().remove(position))) {
                    pitanje.setTacan("");
                    buttonDodajTacan.setEnabled(true);
                }
            }
        });

        buttonDodaj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextOdgovor.getText() == null || editTextOdgovor.getText().toString().trim().equals("") || pitanje.getOdgovori().contains(editTextOdgovor.getText().toString())) {
                    editTextOdgovor.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                } else {
                    pitanje.getOdgovori().add(editTextOdgovor.getText().toString());
                    editTextOdgovor.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    arrayAdapter.notifyDataSetChanged();
                }
            }
        });

        buttonDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextOdgovor.getText() == null || editTextOdgovor.getText().toString().trim().equals("") || pitanje.getOdgovori().contains(editTextOdgovor.getText().toString())) {
                    editTextOdgovor.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                } else {
                    pitanje.getOdgovori().add(editTextOdgovor.getText().toString());
                    pitanje.setTacan(editTextOdgovor.getText().toString());
                    editTextOdgovor.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    arrayAdapter.notifyDataSetChanged();
                    buttonDodajTacan.setEnabled(false);
                }
            }
        });

        buttonDodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean test = false;
                if (editTextNaziv.getText() == null || editTextNaziv.getText().toString().trim().equals("")) {
                    editTextNaziv.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    if (pitanje.getTacan() == null || pitanje.getTacan().equals("")) {
                        listView.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    } else {
                        listView.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    }
                } else {
                    editTextNaziv.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    if (pitanje.getTacan() == null || pitanje.getTacan().equals("")) {
                        listView.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    } else {
                        listView.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                        test = true;
                    }
                }

                if (test) {
                    pitanje.setNaziv(editTextNaziv.getText().toString());
                    if (!Data.getInstance().pitanja.contains(pitanje)) {
                        String odgovori = "";
                        for (int i = 0; i < pitanje.getOdgovori().size(); i++) {
                            odgovori = odgovori + "{\"stringValue\":\"" + pitanje.getOdgovori().get(i) + "\"}";
                            if (i != pitanje.getOdgovori().size() - 1) odgovori = odgovori + ",";
                        }
                        Log.d("ODGOVORI", odgovori);
                        String data = "{\"fields\":{\"indexTacnog\":{\"integerValue\":\"" + pitanje.getOdgovori().indexOf(pitanje.getTacan()) + "\"}, \"naziv\":{\"stringValue\":\"" + pitanje.getNaziv() + "\"}, \"odgovori\":{\"arrayValue\":{\"values\":[" + odgovori + "]}}}}";
                        try {
                            String fid = new PostRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Pitanja?access_token=" + token, data, "POST").get();
                            Data.getInstance().pitanja.add(new Pitanje(pitanje.getNaziv(), pitanje.getTekstPitanja(), pitanje.getOdgovori(), pitanje.getTacan(), fid));
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        Intent intent = new Intent();
                        intent.putExtra("pitanje", pitanje);
                        setResult(101, intent);
                        finish();
                    }
                }
            }
        });
    }
}