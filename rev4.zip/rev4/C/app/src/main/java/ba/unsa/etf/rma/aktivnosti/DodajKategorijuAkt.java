package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import ba.unsa.etf.rma.Async.PostRequestAsync;
import ba.unsa.etf.rma.Data.Data;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import java.util.concurrent.ExecutionException;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.token;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {

    private Icon[] selectedIcons;

    EditText editTextIkona;
    IconDialog iconDialog;
    EditText editTextNaziv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        editTextNaziv = findViewById(R.id.etNaziv);
        editTextIkona = findViewById(R.id.etIkona);
        Button buttonDodajIkonu = findViewById(R.id.btnDodajIkonu);
        Button buttonDodajKategoriju = findViewById(R.id.btnDodajKategoriju);

        iconDialog = new IconDialog();

        buttonDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        buttonDodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean test = false;
                if (editTextNaziv.getText() == null || editTextNaziv.getText().toString().trim().equals("") || Data.getInstance().kategorije.contains(new Kategorija(editTextNaziv.getText().toString(), "", ""))) {
                    editTextNaziv.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    if (editTextIkona.getText() == null || editTextIkona.getText().toString().trim().equals("")) {
                        editTextIkona.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    } else {
                        editTextIkona.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    }
                    if (Data.getInstance().kategorije.contains(new Kategorija(editTextNaziv.getText().toString(), "", ""))) {
                        Toast.makeText(DodajKategorijuAkt.this, "Unesena kategorija već postoji!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    editTextNaziv.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                    if (editTextIkona.getText() == null || editTextIkona.getText().toString().trim().equals("")) {
                        editTextIkona.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    } else {
                        editTextIkona.setBackgroundColor(getResources().getColor(android.R.color.background_light));
                        test = true;
                    }
                }
                if (test) {
                    String data = "{\"fields\":{\"idIkonice\":{\"integerValue\":\"" + editTextIkona.getText().toString() + "\"}, \"naziv\":{\"stringValue\":\"" + editTextNaziv.getText().toString() + "\"}}}";
                    try {
                        String fid = new PostRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Kategorije?access_token=" + token, data, "POST").get();
                        Data.getInstance().kategorije.add(new Kategorija(editTextNaziv.getText().toString(), editTextIkona.getText().toString(), fid));
                        setResult(102, new Intent());
                        finish();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    //new PostRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Kategorije?access_token=" + token, data);
                }
            }
        });
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        editTextIkona.setText(Integer.toString(selectedIcons[0].getId()));
    }
}
