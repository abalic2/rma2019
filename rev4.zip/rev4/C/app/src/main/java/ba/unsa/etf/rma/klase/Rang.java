package ba.unsa.etf.rma.klase;

public class Rang {

    String pozicija, imeIgraca, procenatTacnih;

    public Rang(String pozicija, String imeIgraca, String procenatTacnih) {
        this.pozicija = pozicija;
        this.imeIgraca = imeIgraca;
        this.procenatTacnih = procenatTacnih;
    }

    public String getPozicija() {
        return pozicija;
    }

    public void setPozicija(String pozicija) {
        this.pozicija = pozicija;
    }

    public String getImeIgraca() {
        return imeIgraca;
    }

    public void setImeIgraca(String imeIgraca) {
        this.imeIgraca = imeIgraca;
    }

    public String getProcenatTacnih() {
        return procenatTacnih;
    }

    public void setProcenatTacnih(String procenatTacnih) {
        this.procenatTacnih = procenatTacnih;
    }
}
