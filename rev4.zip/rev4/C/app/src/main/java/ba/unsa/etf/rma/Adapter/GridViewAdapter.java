package ba.unsa.etf.rma.Adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kviz;

public class GridViewAdapter extends BaseAdapter {

    ArrayList<Kviz> kvizovi;
    View gridTile;

    ImageView ikonaKategorije;
    Drawable ikonica;
    TextView nazivKviza, brojPitanja;

    Context context;

    public GridViewAdapter(Context context, ArrayList<Kviz> kvizovi) {
        this.kvizovi = kvizovi;
        this.context = context;
    }

    @Override
    public int getCount() {
        return kvizovi.size();
    }

    @Override
    public Object getItem(int position) {
        return kvizovi.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = ((KvizoviAkt) context).getLayoutInflater().inflate(R.layout.fragment_detail_item, parent, false);

        ikonaKategorije = convertView.findViewById(R.id.ikonaKategorije);
        nazivKviza = convertView.findViewById(R.id.nazivKviza);
        brojPitanja = convertView.findViewById(R.id.brPitanja);
        //kvizovi.get(position).getKategorija().getId();


        if (context != null) {
        }

        if (kvizovi.get(position).getKategorija().getId() != null) {
            int in = Integer.parseInt(kvizovi.get(position).getKategorija().getId());
            //ikonica je null iz nekog razloga. do ikonice je
            /*
            Icon icon = IconHelper.getInstance(context).getIcon(10);
            Log.w("SUCCESS", kvizovi.get(position).getKategorija().getId());
            ikonica = IconHelper.getInstance(context).getIcon(in).getDrawable(context);
            */
            ikonaKategorije.setImageDrawable(IconHelper.getInstance(context).getIcon(in).getDrawable(context));
        } else {
            //ikonica = context.getResources().getDrawable(R.drawable.ic_launcher_background);
            ikonaKategorije.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_launcher_background));
        }

        //ikonica = context.getResources().getDrawable(R.drawable.ic_launcher_background);
        //ikonaKategorije.setImageDrawable(ikonica);
        nazivKviza.setText(kvizovi.get(position).getNaziv());
        if (!kvizovi.get(position).getNaziv().equals("Dodaj kviz"))
            brojPitanja.setText(String.valueOf(kvizovi.get(position).getPitanja().size()));
        else brojPitanja.setVisibility(View.GONE);
        return convertView;
    }

}
