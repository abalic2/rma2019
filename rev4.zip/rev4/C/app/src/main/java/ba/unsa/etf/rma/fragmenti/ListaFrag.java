package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.Async.GetRequestAsync;
import ba.unsa.etf.rma.Data.Data;
import ba.unsa.etf.rma.Data.KvizoviDBOpenHelper;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.util.ConnectivityHelper;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.token;

public class ListaFrag extends Fragment {

    ArrayList<Kviz> kvizovi;
    ArrayList<Kategorija> listaKategorija;
    ArrayList<String> listaKategorijaString;

    ArrayAdapter kategorijeAdapter;
    ListView kategorijeList;

    DetailFrag detailFrag;
    private KvizoviDBOpenHelper kvizoviDBOpenHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_lista, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        kvizoviDBOpenHelper = new KvizoviDBOpenHelper(getContext());

        listaKategorija = (ArrayList<Kategorija>) getArguments().getSerializable("kategorije");
        listaKategorija.addAll(Data.getInstance().kategorije);

        listaKategorijaString = new ArrayList<>();
        kvizovi = new ArrayList<>();

        kategorijeList = getView().findViewById(R.id.listaKategorija);

        for (int i = 0; i < listaKategorija.size(); i++)
            listaKategorijaString.add(listaKategorija.get(i).getNaziv());

        kategorijeAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, listaKategorijaString);
        kategorijeList.setAdapter(kategorijeAdapter);

        kategorijeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (ConnectivityHelper.isNetworkAvailable(getContext())) {
                    Data.getInstance().kvizovi.clear();
                    try {
                        String responseKvizovi = new GetRequestAsync().execute("https://firestore.googleapis.com/v1/projects/rma19nedzibovicamila63/databases/(default)/documents/Kvizovi?access_token=" + token).get();
                        parseKvizovi(responseKvizovi, position);
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                } else {
                    addToList(position);
                }
            }
        });
    }

    public void parseKvizovi(String response, int position) {
        Kategorija katKviza = null;
        JSONObject kvizoviObj;
        try {
            kvizoviObj = new JSONObject(response);
            JSONArray docs = kvizoviObj.getJSONArray("documents");
            for (int i = 0; i < docs.length(); i++) {
                ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();
                JSONObject docsObj = new JSONObject(docs.getString(i));
                String idKviza = docsObj.getString("name");
                String naziv = docsObj.getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                String idKategorije = docsObj.getJSONObject("fields").getJSONObject("idKategorije").getString("stringValue");
                JSONArray kvizoviJSa = docsObj.getJSONObject("fields").getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");

                Log.w("IDIF", idKategorije);
                for (int k = 0; k < Data.getInstance().kategorije.size(); k++) {
                    if (idKategorije.contains(Data.getInstance().kategorije.get(k).getIdInFirebase())) {
                        katKviza = Data.getInstance().kategorije.get(k);
                    }

                }

                //TODO bug: dupla pitanja
                for (int j = 0; j < kvizoviJSa.length(); j++) {
                    JSONObject JSO = new JSONObject(kvizoviJSa.getString(j));
                    String imePitanja = JSO.getString("stringValue");

                    for (int k = 0; k < Data.getInstance().pitanja.size(); k++) {
                        if (imePitanja.contains(Data.getInstance().pitanja.get(k).getIdInFirebase())) {
                            pitanjaUKvizu.add(Data.getInstance().pitanja.get(k));
                        }
                    }

                }
                //Log.w("SUCCESS", "Kat kviza " + katKviza.getNaziv());
                Data.getInstance().kvizovi.add(new Kviz(naziv, pitanjaUKvizu, katKviza, idKviza.substring(70)));
            }
            addToList(position);
        } catch (JSONException e) {
            Log.w("SUCCESS", "Kviz IOe! Value: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void addToList(int position) {
        Kategorija kategorija = listaKategorija.get(position);
        if (position != 0) {
            kvizovi.clear();
            ArrayList<Kviz> adas = Data.getInstance().kvizovi;
            Log.d("SUCCESS", "KVIZOVIsize nakon brisanja: " + kvizovi.size());
            for (int i = 0; i < Data.getInstance().kvizovi.size(); i++) {
                if (kategorija.getId().equals(Data.getInstance().kvizovi.get(i).getKategorijaId())) {
                    Kviz a = Data.getInstance().kvizovi.get(i);
                    a.setKategorija(kategorija);
                    kvizovi.add(a);
                    Log.d("SUCCESS", Data.getInstance().kvizovi.get(i).getNaziv() + " u " + kategorija.getNaziv());
                } else if (kategorija.getNaziv().equals(Data.getInstance().kvizovi.get(i).getKategorija().getNaziv())){
                    kvizovi.add(Data.getInstance().kvizovi.get(i));
                    Log.d("SUCCESS", Data.getInstance().kvizovi.get(i).getNaziv() + " u " + kategorija.getNaziv());
                }
            }
            Log.d("SUCCESS", "KVIZOVIsize nakon dodavanja: " + kvizovi.size());
            if (ConnectivityHelper.isNetworkAvailable(getContext())) {
                Kategorija dodKviz = new Kategorija();
                dodKviz.setId("671");
                kvizovi.add(new Kviz("Dodaj kviz", new ArrayList<Pitanje>(), dodKviz, ""));
            }
            Bundle b = new Bundle();
            b.putSerializable("kategorija", kategorija);
            b.putSerializable("kvizovi", kvizovi);
            detailFrag = new DetailFrag();
            detailFrag.setArguments(b);
            getFragmentManager().beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
        } else {
            kvizovi.clear();
            kvizovi.addAll(Data.getInstance().kvizovi);
            if (ConnectivityHelper.isNetworkAvailable(getContext())) {
                Kategorija dodKviz = new Kategorija();
                dodKviz.setId("671");
                kvizovi.add(new Kviz("Dodaj kviz", new ArrayList<Pitanje>(), dodKviz, ""));
            }
            Bundle b = new Bundle();
            b.putSerializable("kategorija", listaKategorija.get(position));
            b.putSerializable("kvizovi", kvizovi);
            detailFrag = new DetailFrag();
            detailFrag.setArguments(b);
            getFragmentManager().beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
        }
        kategorijeAdapter.notifyDataSetChanged();
    }


    @Override
    public void onResume() {
        super.onResume();
        listaKategorija.clear();
        listaKategorija.add(new Kategorija("Svi", "", ""));
        listaKategorija.addAll(Data.getInstance().kategorije);

        listaKategorijaString.clear();
        for (int i = 0; i < listaKategorija.size(); i++)
            listaKategorijaString.add(listaKategorija.get(i).getNaziv());
        kategorijeAdapter.notifyDataSetChanged();

    }
}
