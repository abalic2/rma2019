package ba.unsa.etf.rma.fragmenti;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.DodajPitanjeAkt;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt.pita;

public class PitanjeFrag extends Fragment {

    ArrayList<Pitanje> pitanja;
    ArrayList<String> odgovori;
    Kviz kviz;
    String nazivKviza;
    Handler handler;
    Runnable runnable;

    TextView nazivPitanja;
    ListView odgovoriLista;

    ArrayAdapter<String> odgovoriAdapter;
    FragmentManager fm;
    InformacijeFrag inf;

    ArrayList<Integer> rand;
    int brojac;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pitanje, container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        odgovoriLista = getView().findViewById(R.id.odgovoriPitanja);
        nazivPitanja = getView().findViewById(R.id.tekstPitanja);

        pitanja = new ArrayList<>();

        kviz = (Kviz) getArguments().getSerializable("kviz");
        nazivKviza = (String) getArguments().getSerializable("Naziv");

        pitanja.addAll(kviz.getPitanja());

        rand = new ArrayList<>();
        for (int i = 0; i < pitanja.size(); i++) rand.add(i);
        Collections.shuffle(rand);

        brojac = 0;
        inicijalizirajPitanje(pitanja.get(rand.get(brojac)), rand.get(brojac));
    }

    public void inicijalizirajPitanje(Pitanje pitanje, int pitanjeIndex) {
        odgovori = new ArrayList<>();
        odgovoriAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, odgovori);

        for (int i = 0; i < pitanje.getOdgovori().size(); i++) {
            odgovori.add(pitanje.getOdgovori().get(i));
        }

        odgovoriLista.setAdapter(odgovoriAdapter);
        postaviPitanje(pitanje, pitanjeIndex, Integer.parseInt(pitanje.getTacan()));
    }

    boolean tacanOdg;

    public void postaviPitanje(final Pitanje pitanje, final int pitanjeIndex, final int tacanIndex) {
        nazivPitanja.setText(pitanje.getNaziv());
        odgovoriLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == Integer.valueOf(pitanje.getTacan())) {
                    odgovoriLista.getChildAt(position).setBackgroundColor(getResources().getColor(R.color.zelena));
                    Log.d("SUCCESSvaluechangeT", String.valueOf(tacanOdg));
                    tacanOdg = true;
                } else {
                    odgovoriLista.getChildAt(position).setBackgroundColor(getResources().getColor(R.color.crvena));
                    odgovoriLista.getChildAt(tacanIndex).setBackgroundColor(getResources().getColor(R.color.zelena));
                    Log.d("SUCCESSvaluechangeF", String.valueOf(tacanOdg));
                    tacanOdg = false;
                }

                final int n = position;
                handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        odgovoriLista.getChildAt(n).setBackgroundColor(getResources().getColor(android.R.color.transparent));
                        odgovori.clear();
                        ++brojac;
                        if (brojac != pitanja.size())
                            inicijalizirajPitanje(pitanja.get(rand.get(brojac)), rand.get(brojac));
                        if (brojac == pitanja.size()) {
                            nazivPitanja.setText("Kviz je završen!");
                            imeIgracaDialog();
                            odgovori.clear();
                            odgovoriAdapter.notifyDataSetChanged();
                        }
                        azurirajPodatke(tacanOdg, brojac);
                    }
                }, 2000);
            }
        });
    }

    public void azurirajPodatke(boolean isTacan, int trenutnoPitanje) {
        inf = (InformacijeFrag) getFragmentManager().findFragmentById(R.id.InformacijePlace);
        inf.azuriraj(isTacan, pitanja.size() - trenutnoPitanje);
    }

    public String getProcenatTacnih() {
        inf = (InformacijeFrag) getFragmentManager().findFragmentById(R.id.InformacijePlace);
        return inf.dajProcTacnih();
    }

    EditText username;
    public void imeIgracaDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
        View v = View.inflate(getContext(), R.layout.dialog_ime, null);

       username = v.findViewById(R.id.imeIgraca);

        alertDialogBuilder
                .setView(v)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (TextUtils.isEmpty(username.getText())) {
                            username.setError("Unesite korisničko ime!");
                        } else {
                            if (pita != null) {
                                Bundle bundle = new Bundle();
                                bundle.putSerializable("Naziv", nazivKviza);
                                bundle.putSerializable("Igrac", username.getText().toString());
                                bundle.putSerializable("Tacnih", getProcenatTacnih());
                                RangLista rl = new RangLista();
                                rl.setArguments(bundle);
                                getFragmentManager().beginTransaction().replace(R.id.PitanjePlace, rl).commit();
                                Log.d("FMGR", "Transaction to RangLista successfull");
                            }
                        }
                    }
                })
                .setNegativeButton("Otkaži", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .setCancelable(true);

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

}
