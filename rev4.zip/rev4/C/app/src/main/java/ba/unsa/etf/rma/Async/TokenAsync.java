package ba.unsa.etf.rma.Async;

import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;

import java.io.IOException;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.gcredential;

public class TokenAsync extends AsyncTask<GoogleCredential, GoogleCredential, GoogleCredential> {

    @Override
    protected GoogleCredential doInBackground(GoogleCredential... credentials) {
        try {
            Log.w("TOKEN", "refreshing...");
            gcredential.refreshToken();
        } catch (IOException e) {
            Log.w("TOKEN", "Async IOe: " + e.getMessage());
            e.printStackTrace();
        }
        return gcredential;
    }
}
