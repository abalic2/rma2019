package ba.unsa.etf.drma;

public interface AsyncResponse {
    void processFinish(String output);
}
