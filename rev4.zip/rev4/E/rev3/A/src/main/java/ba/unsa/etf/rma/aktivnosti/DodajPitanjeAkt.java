package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.AdapterZaListuOdgovora;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {
    AdapterZaListuOdgovora adapterZaOdgovore;
    ArrayList<String> odgovori = new ArrayList<>();
    ArrayList<Pitanje> pitanja = new ArrayList<>();
    Intent intent;
    ListView listaodgovora;
    Button dodajOdgovor, dodajTacan, dodajPitanje;
    EditText upisiIme, upisiOdgovor;
    String tacanOdgovor, TOKEN;
    int kojePitanjeJeDoslo;
    boolean daLiJeUnesenTacanOdgovor = false;
    Pitanje novoPitanje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodavanje_pitanja);
        new DajToken().execute("dajToken");



        listaodgovora = (ListView) findViewById(R.id.lvOdgovori);
        dodajOdgovor = (Button) findViewById(R.id.btnDodajOdgovor);
        dodajTacan = (Button) findViewById(R.id.btnDodajTacan);
        upisiIme = (EditText) findViewById(R.id.etNaziv);
        upisiOdgovor = (EditText) findViewById(R.id.etOdgovor);
        dodajPitanje = (Button) findViewById(R.id.btnDodajPitanje);

        intent = getIntent();
        kojePitanjeJeDoslo = intent.getIntExtra("kojePitanjeJePritisnuto", -1);
        if(intent.getParcelableArrayListExtra("odgovori") != null){
            pitanja = intent.getParcelableArrayListExtra("odgovori");
        }

        adapterZaOdgovore = new AdapterZaListuOdgovora(this, odgovori, getResources());
        listaodgovora.setAdapter(adapterZaOdgovore);

        listaodgovora.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position < adapterZaOdgovore.getPozicija()){
                    adapterZaOdgovore.setPozicija(adapterZaOdgovore.getPozicija() - 1);
                }
                else if(position == adapterZaOdgovore.getPozicija()){
                    daLiJeUnesenTacanOdgovor = false;
                    adapterZaOdgovore.setPozicija(-1);
                }

                odgovori.remove(position);
                adapterZaOdgovore.notifyDataSetChanged();
            }
        });

        dodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(upisiOdgovor.getText().toString().matches("")){
                    upisiOdgovor.setBackgroundColor(Color.RED);
                }else{
                    odgovori.add(upisiOdgovor.getText().toString());
                    upisiOdgovor.setText("");
                    adapterZaOdgovore.notifyDataSetChanged();
                }
            }
        });

        dodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(daLiJeUnesenTacanOdgovor){
                    upisiOdgovor.setText("");
                    Toast.makeText(getApplicationContext(), "Tacan odgovor je vec unesen", Toast.LENGTH_SHORT).show();
                } else if(upisiOdgovor.getText().toString().matches("")){
                    upisiOdgovor.setBackgroundColor(Color.RED);
                }else{
                    adapterZaOdgovore.setPozicija(odgovori.size());
                    odgovori.add(upisiOdgovor.getText().toString());
                    tacanOdgovor = upisiOdgovor.getText().toString();
                    adapterZaOdgovore.notifyDataSetChanged();
                    daLiJeUnesenTacanOdgovor = true;
                    upisiOdgovor.setText("");
                }

            }
        });

        dodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean postojiLi = false;


                for(Pitanje i : pitanja){
                    if(upisiIme.getText().toString().equals(i.getNaziv().toString())){
                        Toast.makeText(getApplicationContext(), "Pitanje s tim imenom vec postoji, ponovite unos", Toast.LENGTH_SHORT).show();
                        upisiIme.setBackgroundColor(Color.RED);
                        upisiIme.setText("");
                        postojiLi = true;
                        break;
                    }
                }

                if(upisiIme.getText().toString().matches("")){
                    upisiIme.setBackgroundColor(Color.RED);
                } else if(!daLiJeUnesenTacanOdgovor){
                    Toast.makeText(getApplicationContext(), "Morate unijeti tacan odgovor", Toast.LENGTH_SHORT).show();
                } else if(!postojiLi){
                    novoPitanje = new Pitanje(upisiIme.getText().toString(), upisiIme.getText().toString(), tacanOdgovor, odgovori);
                    new PostojiLiPitanje().execute("Pitanja", novoPitanje.getNaziv());
                }
            }
        });
    }

    private class PostojiLiPitanje extends AsyncTask<String, Integer, Integer> {

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if (integer == 1) {
                Intent saljiPitanje = new Intent(getApplicationContext(), DodajKvizAkt.class);
                saljiPitanje.putExtra("novoPitanje", novoPitanje);
                saljiPitanje.putStringArrayListExtra("odg", odgovori);
                setResult(RESULT_OK, saljiPitanje);
                finish();
            } else {
                AlertDialog alertDialog = new AlertDialog.Builder(DodajPitanjeAkt.this).create();
                alertDialog.setTitle("Greska");
                alertDialog.setMessage("Pitanje pod tim imenom vec postoji!");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        }

        protected Integer doInBackground(String... urls) {
            try {
                String url1;
                if (urls.length == 1)
                    url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "?access_token=" + TOKEN;
                else
                    url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "/" + urls[1] + "?access_token=" + TOKEN;
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                return 1;
            }
            return 0;
        }
    }

    private class DajToken extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential googleCredential;
            try {
                InputStream tajna = getResources().openRawResource(R.raw.secret);
                googleCredential = GoogleCredential.fromStream(tajna).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));

                googleCredential.refreshToken();
                TOKEN = googleCredential.getAccessToken();
                Log.d("TOKEN", TOKEN);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

}
