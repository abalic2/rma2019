package ba.unsa.etf.rma.aktivnosti;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity implements InformacijeFrag.InformacijeFragListener, PitanjeFrag.PitanjeFragListener {

    private PitanjeFrag pitanjeFrag;
    private InformacijeFrag informacijeFrag;
    private Intent intent;
    private FragmentManager fm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        intent = getIntent();
        fm = getSupportFragmentManager();

        Kviz kviz = intent.getParcelableExtra("kviz");
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        pitanja = intent.getParcelableArrayListExtra("pitanja");


        for(Pitanje p : pitanja){
            if(p.getNaziv().equalsIgnoreCase("Dodaj pitanje")){
                pitanja.remove(p);
                break;
            }
        }



        FrameLayout info = (FrameLayout) findViewById(R.id.informacijePlace);
        FrameLayout ques = (FrameLayout) findViewById(R.id.pitanjePlace);



        if(informacijeFrag == null){

            informacijeFrag = new InformacijeFrag();

            Bundle argumenti=new Bundle();
            argumenti.putParcelable("kviz", kviz);
            argumenti.putParcelableArrayList("pitanja", pitanja);
            informacijeFrag.setArguments(argumenti);

            fm.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
        }

        if(pitanjeFrag == null){

            pitanjeFrag = new PitanjeFrag();

            Bundle argumenti=new Bundle();
            argumenti.putParcelable("kviz", kviz);
            argumenti.putParcelableArrayList("pitanja", pitanja);
            pitanjeFrag.setArguments(argumenti);

            fm.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();
        }


    }

    @Override
    public void onInputASent(CharSequence tacni, CharSequence preostali, CharSequence procenat) {
        informacijeFrag.updateEditText(tacni, preostali, procenat);
    }

    @Override
    public void onInputBSent(CharSequence brojTacnihChar, CharSequence brojPreostalihChar, CharSequence postotakTacnihChar) {
        //ne radi se nista
    }
}
