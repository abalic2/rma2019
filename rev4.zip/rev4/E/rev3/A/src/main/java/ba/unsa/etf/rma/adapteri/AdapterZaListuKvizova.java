package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Icon;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class AdapterZaListuKvizova extends BaseAdapter {

    Activity context;
    ArrayList<Kviz> kvizovi;
    private static LayoutInflater infalter = null;
    Resources resources;

    public AdapterZaListuKvizova(Activity context, ArrayList<Kviz> kvizovi, Resources res){
        this.context = context;
        this.kvizovi = kvizovi;
        resources = res;

        infalter =(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public int getCount() {
        return kvizovi.size();
    }

    @Override
    public Object getItem(int position) {
        return kvizovi.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        itemView = (itemView == null) ? infalter.inflate(R.layout.element_liste, null) : itemView;

        TextView ime = (TextView) itemView.findViewById(R.id.kviz);
        IconView slikaKategorije = (IconView) itemView.findViewById(R.id.slikaKategorije);

        Kviz m = kvizovi.get(position);

        ime.setText(m.getNaziv());

        if(m.getKategorija() == null) slikaKategorije.setImageResource(R.drawable.dodaj); //PROMJENA
        else if(m.getKategorija().getId().equalsIgnoreCase("svi")) slikaKategorije.setImageResource(R.drawable.novi);
        else if(m.getKategorija().getId().equalsIgnoreCase("sport")) slikaKategorije.setImageResource(R.drawable.sport);
        else if(m.getKategorija().getId().equalsIgnoreCase("nauka")) slikaKategorije.setImageResource(R.drawable.nauka);
        else if(m.getKategorija().getId().equalsIgnoreCase("knjizevnost")) slikaKategorije.setImageResource(R.drawable.knjizevnost);
        else slikaKategorije.setIcon(Integer.parseInt(m.getKategorija().getId()));

        return itemView;
    }
}