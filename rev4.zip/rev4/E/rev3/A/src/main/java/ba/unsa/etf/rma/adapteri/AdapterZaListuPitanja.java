package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class AdapterZaListuPitanja extends BaseAdapter {

    Activity context;
    ArrayList<Pitanje> pitanja;
    private static LayoutInflater infalter = null;
    Resources resources;

    public AdapterZaListuPitanja(Activity context, ArrayList<Pitanje> pitanja, Resources res){
        this.context = context;
        this.pitanja = pitanja;
        resources = res;

        infalter =(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public int getCount() {
        return pitanja.size();
    }

    @Override
    public Pitanje getItem(int position) {
        return pitanja.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        itemView = (itemView == null) ? infalter.inflate(R.layout.element_liste_pitanja, null) : itemView;

        TextView pitanje = (TextView) itemView.findViewById(R.id.pitanje);

        Pitanje m = pitanja.get(position);

        pitanje.setText(m.getNaziv());

        return itemView;
    }
}
