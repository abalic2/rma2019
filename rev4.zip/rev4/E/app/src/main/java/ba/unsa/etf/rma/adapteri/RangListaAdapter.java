package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.RangItem;

public class RangListaAdapter extends ArrayAdapter<RangItem> {

    private final int resource;

    public RangListaAdapter(Context context, int resource, List<RangItem> objects) {
        super(context, resource, objects);
        this.resource = resource;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LinearLayout view=null;
        if(convertView==null){
            view = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater li;
            li = (LayoutInflater)getContext().
                    getSystemService(inflater);
            li.inflate(resource, view, true);
        }else{
            view = (LinearLayout) convertView;
        }
        TextView itemNumber = view.findViewById(R.id.rank);
        TextView name = view.findViewById(R.id.name);
        TextView score = view.findViewById(R.id.score);
        RangItem item = getItem(position);
        itemNumber.setText((position+1)+"");
        name.setText(item.getUser());
        score.setText(item.getResult().toString());

        return view;

    }
}
