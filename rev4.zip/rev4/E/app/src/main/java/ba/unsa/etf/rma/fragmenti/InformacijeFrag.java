package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;


public class InformacijeFrag extends Fragment {

    private Kviz kviz;
    private Integer brojPreostalihPitanja;
    private Integer brojTacnih;

    private TextView nazivKviza;
    private TextView brojTacnihText;
    private TextView brojPreostalihText;
    private TextView procenatTacnih;
    private Button endingButton;

    private OnFragmentInteractionListener mListener;
    private Integer brojOdgovorenih;

    public InformacijeFrag() {
        // Required empty public constructor
    }

    public static InformacijeFrag newInstance(Kviz kviz) {
        InformacijeFrag fragment = new InformacijeFrag();
        Bundle args = new Bundle();
        args.putSerializable("kviz",kviz);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            kviz = (Kviz)getArguments().getSerializable("kviz");
            brojOdgovorenih=0;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_informacije, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        findViewElements();
        setInitialValues();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void endGame();
    }

    private void setInitialValues() {
        brojTacnih=0;
        brojPreostalihPitanja = kviz.getPitanja().size()-1;
        nazivKviza.setText(kviz.getNaziv());
        refreshKvizStatistics();
        endingButton.setOnClickListener(v -> mListener.endGame());
    }

    public void proceed(Boolean answeredRight) {
        if(brojPreostalihPitanja<0)throw new IllegalStateException("Quiz has been completed");
        if (answeredRight) {
            brojTacnih++;
        }
        if(brojPreostalihPitanja!=0)brojPreostalihPitanja--;
        refreshKvizStatistics();
    }


    private void refreshKvizStatistics() {
        brojTacnihText.setText(String.valueOf(brojTacnih));
        brojPreostalihText.setText(String.valueOf((brojPreostalihPitanja<0)?0:brojPreostalihPitanja));
        procenatTacnih.setText(String.format("%s%%", String.valueOf(
                (brojOdgovorenih==0) ?
                        0 :
                        Double.valueOf(brojTacnih) / (brojOdgovorenih) * 100)));
        brojOdgovorenih++;
    }

    private void findViewElements() {
        nazivKviza = getActivity().findViewById(R.id.infNazivKviza);
        brojTacnihText = getActivity().findViewById(R.id.infBrojTacnihPitanja);
        brojPreostalihText = getActivity().findViewById(R.id.infBrojPreostalihPitanja);
        procenatTacnih = getActivity().findViewById(R.id.infProcenatTacni);
        endingButton = getActivity().findViewById(R.id.btnKraj);
    }

    public Double getResult(){
        return Double.parseDouble(procenatTacnih.getText().toString().replace("%",""));
    }
}
