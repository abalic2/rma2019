package ba.unsa.etf.rma;

import android.content.Context;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;


public class DataAccessLayer {
    private static DataAccessLayer instance=null;
    private static ArrayList<Kviz> kvizovi=null;
    private static ArrayList<Kategorija> kategorije=null;
    private static String token;

    private DataAccessLayer(){

    }

    public static DataAccessLayer getInstance(){
        if (instance == null) {
            instance = new DataAccessLayer();
            kvizovi = new ArrayList<>();
            kategorije = new ArrayList<>();
        }
        return instance;
    }

    public ArrayList<Kviz> getKvizovi() {

        return kvizovi;
    }

    public void dodajKviz(Kviz kviz, Context context){
        getAccessToken(context);

        if (kvizovi.contains(kviz)) {
            throw new IllegalArgumentException("Postoji već");
        }
        kvizovi.add(kvizovi.size(),kviz);
    }

    private void getAccessToken(Context context) {
        InputStream inputStream = context.getResources().openRawResource(R.raw.secret);
        try {
            GoogleCredential credentials = GoogleCredential.fromStream(inputStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            System.out.println("Uspjesno getovan token : " + token);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void editKviz(Kviz oldValue, Kviz newValue){
        kvizovi.set(kvizovi.indexOf(oldValue),newValue);
    }

    public void dodajKategoriju(Kategorija kategorija){
        if(kategorije.contains(kategorija)) throw new IllegalArgumentException("Već postoji!");
        kategorije.add( kategorija);
    }

    public ArrayList<Kategorija> getKategorije(Context context) {
        if(context.getClass() == KvizoviAkt.class)
        System.out.println("\n\n\n\naaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaa\naaaaaaaaaaaaaa\naaaaaaaaaaa\n\n\n");
//        getAccessToken(context);
////        JSONObject obj1 = new JSONObject(" .... ");
////        String pageName = obj1.getJSONObject("pageInfo").getString("pageName");
////
////        JSONArray arr = obj1.getJSONArray("posts");
////        for (int i = 0; i < arr.length(); i++)
////        {
////            String post_id = arr.getJSONObject(i).getString("post_id");
////
////        }
//
//        try {
//            KategorijaGetter kategorijaGetter = (KategorijaGetter) new KategorijaGetter().execute(token);
//            ArrayList<Kategorija> temp = kategorijaGetter.get();
//        } catch (ExecutionException e) {
//            System.out.println(e.getMessage());
//        } catch (InterruptedException e) {
//            System.out.println(e.getMessage());
//        }

        return kategorije;
    }

    public ArrayList<Kviz> getKvizoviWithFilter(String filter){
        ArrayList<Kviz> result = new ArrayList<>();
        for (Kviz kviz : kvizovi) {
            if (kviz.getKategorija().getNaziv().equals(filter) || filter.equals("Svi")) {
                result.add(kviz);
            }
        }
        return result;
    }
}
