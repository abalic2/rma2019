package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.GridKvizAdapter;
import ba.unsa.etf.rma.klase.Kviz;


public class DetailFrag extends Fragment {

    private ArrayList<Kviz> kvizovi;
    private OnFragmentInteractionListener mListener;
    private GridView kvizGrid;
    private GridKvizAdapter gridKvizAdapter;

    public DetailFrag() {
        // Required empty public constructor
    }

    public static DetailFrag newInstance(ArrayList<Kviz> kvizovi) {
        DetailFrag fragment = new DetailFrag();
        Bundle args = new Bundle();
        args.putSerializable("kvizovi", kvizovi);
        fragment.setArguments(args);
        return fragment;
    }

    public void refresh(){
        gridKvizAdapter.notifyDataSetChanged();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            kvizovi = (ArrayList<Kviz>) getArguments().getSerializable("kvizovi");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_detail, container, false);
        kvizGrid = view.findViewById(R.id.gridKvizovi);
        gridKvizAdapter = new GridKvizAdapter(getContext(), R.layout.kviz_grid_cell, kvizovi);
        kvizGrid.setAdapter(gridKvizAdapter);
        kvizGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == kvizovi.size() - 1) {

                }else{
                    mListener.playKviz(kvizovi.get(position));
                }
            }
        });
        kvizGrid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == kvizovi.size() - 1) {
                    mListener.addKviz();
                } else {
                    mListener.editKviz(kvizovi.get(position));
                }
                return false;
            }
        });
        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {

        void playKviz(Kviz kviz);

        void addKviz();

        void editKviz(Kviz kviz);
    }
}
