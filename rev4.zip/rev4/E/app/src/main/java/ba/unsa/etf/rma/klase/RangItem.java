package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class RangItem implements Comparable, Serializable {
    private String user;
    private Double result;

    public RangItem() {
    }

    public RangItem(String user, Double result) {
        this.user = user;
        this.result = result;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Double getResult() {
        return result;
    }

    public void setResult(Double result) {
        this.result = result;
    }


    @Override
    public String toString() {
        return getUser()+" : "+getResult();
    }

    @Override
    public int compareTo(Object o) {
        if(!(o instanceof RangItem))return -1;
        RangItem item = (RangItem) o;
        if(result.compareTo(item.getResult()) == 0){
         if(user.compareTo(item.getUser())==0)return -1;
         return user.compareTo(item.getUser());
        }
        return item.getResult().compareTo(result);
    }

}
