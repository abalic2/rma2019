package ba.unsa.etf.rma.tasks;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangItem;
import ba.unsa.etf.rma.klase.RangLista;

public class Creator {
    public static ArrayList<Kategorija> kategorijeFromJSON(String json){
        ArrayList<Kategorija> kategorijas = new ArrayList<>();
        try {
            JSONArray documents = new JSONArray(json);
            for (int i = 0; i<documents.length();i++) {
                JSONObject document = documents.getJSONObject(i);
                document = document.getJSONObject("document");
                JSONObject fields = document.getJSONObject("fields");
                String naziv = fields.getJSONObject("naziv").getString("stringValue");
                int idIkonice = fields.getJSONObject("idIkonice").getInt("integerValue");
                Kategorija kategorija = new Kategorija(naziv, String.valueOf(idIkonice));
                kategorijas.add(kategorija);
            }
        } catch (JSONException e) {
            System.out.println("---- "+e.getMessage());
        }
        return kategorijas;
    }

    public static ArrayList<Pitanje> pitanjaFromJSON(String json){
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        try{
            JSONArray documents = new JSONArray(json);
            for(int i=0;i<documents.length();i++){
                JSONObject document = documents.getJSONObject(i).getJSONObject("document");
                JSONObject fields = document.getJSONObject("fields");
                int indexTacnog = fields.getJSONObject("indexTacnog").getInt("integerValue");
                String naziv = fields.getJSONObject("naziv").getString("stringValue");
                JSONArray odgovoriJSON = fields.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                ArrayList<String> odgovori = new ArrayList<>();
                for(int j=0;j<odgovoriJSON.length();j++){
                    odgovori.add(odgovoriJSON.getJSONObject(j).getString("stringValue"));
                }
                Pitanje pitanje = new Pitanje(naziv,naziv,odgovori,odgovori.get(indexTacnog));
                pitanja.add(pitanje);
            }
        } catch (JSONException e) {
            System.out.println("aaaaaaaaa"+e.getMessage());
        }
        return pitanja;
    }

    public static ArrayList<Kviz> kvizoviFromJSON(String json, String kategorijaJSON, ArrayList<Pitanje> pitanja) {
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        ArrayList<Kategorija> kategorije = kategorijeFromJSON(kategorijaJSON);
        Kategorija kategorija = new Kategorija("Svi",String.valueOf(android.R.drawable.btn_radio));

        try{
            JSONArray documents = new JSONArray(json);
            for(int i=0;i<documents.length();i++) {
                JSONObject document = documents.getJSONObject(i).getJSONObject("document");
                JSONObject fields = document.getJSONObject("fields");
                String naziv = fields.getJSONObject("naziv").getString("stringValue");
                String idKategorije = fields.getJSONObject("idKategorije").getString("stringValue");
                JSONArray pitanjaJSON = fields.getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");
                Kviz kviz = new Kviz();
                kviz.setNaziv(naziv);
                if(kategorije.size()!=0){
                    for(int j=0;j<kategorije.size();j++){
                        if(kategorije.get(j).getNaziv().equals(idKategorije)){
                            kategorija = kategorije.get(j);
                        }
                    }
                }kviz.setKategorija(kategorija);
                for (int j = 0; j < pitanjaJSON.length(); j++) {
                    for (Pitanje pitanje : pitanja) {
                        if (pitanje.getNaziv().equals(pitanjaJSON.getJSONObject(j).getString("stringValue"))) {
                                kviz.dodajNovoPitanje(pitanje);
                                break;
                        }
                    }
                }
                kvizovi.add(kviz);
            }
        } catch (JSONException e) {
            System.out.println("00000000"+e.getMessage());
        }
        System.out.println(kvizovi);
        return kvizovi;
    }

    public static ArrayList<RangLista> rangListafromJSON(String rangListaJSON) {
        ArrayList<RangLista> rangListas = new ArrayList<>();
        RangLista rangLista=null;
        try {
            JSONArray documents = new JSONArray(rangListaJSON);
            for (int i = 0; i < documents.length();i++) {
                rangLista = new RangLista();
                JSONObject document = documents.getJSONObject(i).getJSONObject("document");
                JSONObject fields = document.getJSONObject("fields");
                String nazivKviza = fields.getJSONObject("nazivKviza").getString("stringValue");
                rangLista.setKviz(nazivKviza);
                JSONObject rangovi = fields.getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
                RangItem rangItem = null;
                for (Iterator<String> it = rangovi.keys(); it.hasNext(); ) {
                    String rang = it.next();
                    JSONObject users = rangovi.getJSONObject(rang).getJSONObject("mapValue").getJSONObject("fields");
                    for (Iterator<String> it2 = users.keys(); it2.hasNext();) {
                        String user = it2.next();
                        rangItem = new RangItem(user,users.getJSONObject(user).getDouble(users.getJSONObject(user).keys().next()));
                        rangLista.addRangItem(rangItem);
                    }
                }
                rangListas.add(rangLista);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return rangListas;
    }


    public static String rangListaToJSON(RangLista rangLista){
        String result = "";
        String items = "{\"fields\":{" +
                "\"nazivKviza\": {\"stringValue\": \""+rangLista.getKviz()+"\"}," +
                "\"lista\":\n" +
                "                    {\n" +
                "                        \"mapValue\":\n" +
                "                            {\n" +
                "                                \"fields\":\n" +
                "                                {";
        ArrayList<RangItem> rangItems = new ArrayList<>(rangLista.getLista());
        for(int i=0;i<rangItems.size();i++){
            if(i!=0){
                items+=",";
            }
            items+="\""+(i+1)+"\":{\"mapValue\":{\"fields\":{\""
                        +rangItems.get(i).getUser()+"\": {\"doubleValue\":"
                        +rangItems.get(i).getResult()+"}}}}";
        }
        result = items + "}\n" +
                            "}\n" +
                            "}\n" +
                            "}}";
        return result;
    }

}