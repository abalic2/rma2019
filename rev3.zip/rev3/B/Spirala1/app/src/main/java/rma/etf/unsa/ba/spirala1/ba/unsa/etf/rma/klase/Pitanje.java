package rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Pitanje implements Serializable {
    private String naziv;
    private String tekstPitanja;
    private ArrayList<String> odgovori;
    private String tacan;
    static int brojPitanja = 0;
    private int id;

    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.odgovori = odgovori;
        this.tacan = tacan;
        this.id = brojPitanja++;
    }
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
    public String getNaziv() {
        return naziv;
    }
    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }
    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public String getTacan() {
        return tacan;
    }

    public int getId() { return id; }

    public ArrayList<String> dajRandomOdgovore() {
        Collections.shuffle(odgovori);
        return odgovori;
    }


    public boolean equals(Object e) {
        Pitanje uporedi = (Pitanje)e;
        return this.naziv.equals(uporedi.naziv) && this.tekstPitanja.equals(uporedi.tekstPitanja) &&
                this.odgovori.equals(uporedi.odgovori) && this.tacan.equals(uporedi.tacan);
    }
}
