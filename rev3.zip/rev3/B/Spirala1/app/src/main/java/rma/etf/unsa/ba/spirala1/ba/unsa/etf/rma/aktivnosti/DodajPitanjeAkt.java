package rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.aktivnosti;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import rma.etf.unsa.ba.spirala1.R;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {
    ArrayList<Pitanje> svaPitanja;
    ArrayList<String> odgovori;
    String tacan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(rma.etf.unsa.ba.spirala1.R.layout.activity_dodaj_pitanje_akt);

        svaPitanja = (ArrayList<Pitanje>)getIntent().getSerializableExtra("SvaPitanja");

        EditText editTextNaziv = findViewById(R.id.etNaziv);
        EditText editTextOdgovor = findViewById(R.id.etOdgovor);
        ListView listViewOdgovori = findViewById(R.id.lvOdgovori);
        Button buttonDodajOdgovor = findViewById(R.id.btnDodajOdgovor);
        Button buttonDodajTacan = findViewById(R.id.btnDodajTacan);
        Button buttonDodajPitanje = findViewById(R.id.btnDodajPitanje);


    }
}
