package rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import rma.etf.unsa.ba.spirala1.R;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.Kategorija;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.Kviz;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.KvizAdapter;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.Pitanje;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.SpinnerAdapter;

public class KvizoviAkt extends AppCompatActivity {
    ArrayList<Kategorija> listaKategorija = new ArrayList<Kategorija>();
    ArrayList<Kviz> listaKvizova = new ArrayList<>();
    ArrayList<Pitanje> listaPitanja = new ArrayList<>();
    KvizAdapter kvizoviAdapter;
    SpinnerAdapter kategorijeAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(rma.etf.unsa.ba.spirala1.R.layout.activity_kvizovi_akt);

        kvizoviAdapter = new KvizAdapter(this, R.layout.kviz_list_item, listaKvizova);
        kategorijeAdapter = new SpinnerAdapter(this, R.layout.kviz_list_item, listaKategorija);

        final Spinner kategorije = (Spinner)findViewById(R.id.spPostojeceKategorije);
        final ListView kvizovi = (ListView)findViewById(R.id.lvKvizovi);


        listaPitanja.add(new Pitanje("Dodaj Pitanje", null, new ArrayList<String>(), null));
        listaPitanja.add(0, new Pitanje("Testno pitanje",
                "Testni tekst pitanja",
                new ArrayList<String>(Arrays.asList("odgovor1", "odgovor2")),
                "odgovor1"));
        listaPitanja.add(0, new Pitanje("Testno pitanje2",
                "Testni tekst pitanja2",
                new ArrayList<String>(Arrays.asList("odgovor12", "odgovor22")),
                "odgovor12"));

        listaKvizova.add(new Kviz("Dodaj Kviz", new ArrayList<Pitanje>(), new Kategorija()));
        listaKvizova.add(0, new Kviz("Testni kviz",
                new ArrayList<Pitanje>(Arrays.asList(listaPitanja.get(0))),
                new Kategorija("Testna kategorija", "0000")));

        listaKategorija.add(new Kategorija("Svi", "0000") );


        kvizovi.setAdapter(kvizoviAdapter);
        kategorije.setAdapter(kategorijeAdapter);


        kvizoviAdapter.notifyDataSetChanged();
        kategorijeAdapter.notifyDataSetChanged();

        kvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                myIntent.putExtra("Kategorije", listaKategorija);
                myIntent.putExtra("SvaPitanja", listaPitanja);
                myIntent.putExtra("SviKvizovi", listaKvizova);

                if(kvizoviAdapter.getItem(position).getId() != 0) {
                    myIntent.putExtra("Novi", false);
                    myIntent.putExtra("Indeks", position);
                }
                else {
                    myIntent.putExtra("Novi", true);
                }

                startActivityForResult(myIntent, 0);
            }
        });
        kategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                Kategorija clickedKategorija = (Kategorija) parent.getItemAtPosition(position);
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(resultCode == RESULT_OK){
            listaKategorija.clear();
            listaKvizova.clear();
            listaKategorija.addAll((ArrayList<Kategorija>)data.getSerializableExtra("Kategorije"));
            listaKvizova.addAll((ArrayList<Kviz>)data.getSerializableExtra("SviKvizovi"));
            listaPitanja = (ArrayList<Pitanje>)data.getSerializableExtra("SvaPitanja");
            kvizoviAdapter.notifyDataSetChanged();
            kategorijeAdapter.notifyDataSetChanged();
        }

    }

}
