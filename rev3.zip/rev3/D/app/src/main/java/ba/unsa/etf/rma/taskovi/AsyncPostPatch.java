package ba.unsa.etf.rma.taskovi;

import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.RangPodaci;


public class AsyncPostPatch extends AsyncTask<IParselableBaza, Integer, String> {

    private InputStream stream;
    private GoogleCredential credentials;
    private IParselableBaza object;
    private  OnUploaded pozivatelj;
    private String akcija;

    public AsyncPostPatch(InputStream stream, String akcija, OnUploaded pozivatelj) {
        this.stream = stream;
        this.akcija = akcija;
        this.pozivatelj=pozivatelj;
    }

    public interface  OnUploaded{
       void onUploadDone(IParselableBaza object, String id);
    }
    @Override
    protected String doInBackground(IParselableBaza... objects) {


        try {
            credentials=GoogleCredential.fromStream(stream).createScoped(Lists.<String>newArrayList("https://www.googleapis.com/auth/datastore"));
            object=objects[0];
            HttpURLConnection conn = getConnection();

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = TaskExec.getStringZaUnos(object).getBytes("UTF-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();

        } catch (IOException e) {
            e.printStackTrace();

        }


        return null;
    }

    private HttpURLConnection getConnection() throws IOException {

        credentials.refreshToken();
        String TOKEN=credentials.getAccessToken();

        String extra="",extra2="&";

        if(akcija.equals("PATCH")) {
            extra="/";
            extra2="?";
        }
        if(object instanceof Kviz || object instanceof RangPodaci) extra2="?";
        String url="https://firestore.googleapis.com/v1/projects/spirala-a85a9/databases/(default)/documents/"+
                TaskExec.getNazivKolekcije(object)+extra+object.getIdBaza()+extra2+"access_token=";
        URL urlObj=new  URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));

        HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod(akcija);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");

        return  conn;

    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if(pozivatelj==null) return;
        if(object instanceof RangPodaci) pozivatelj.onUploadDone(object,s);
        else if(akcija.equals("POST"))
           pozivatelj.onUploadDone(object,s);
    }
}
