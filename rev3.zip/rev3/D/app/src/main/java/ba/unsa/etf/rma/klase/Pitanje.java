package ba.unsa.etf.rma.klase;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.taskovi.IParselableBaza;

public class Pitanje implements java.io.Serializable, Pregled, IParselableBaza {
    private String naziv,tekstPitanja, tacan,id;
    private ArrayList<String> odgovori;
    private static Pitanje dodaj_pitanje=new Pitanje("Dodaj Pitanje");

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }


    public ArrayList<String> dajRandomOdgovore(){
        Collections.shuffle(odgovori);
        return odgovori;
    }

    public Pitanje() {
    }

    public Pitanje(String naziv, String tekstPitanja, String tacan, ArrayList<String> odgovori) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.tacan = tacan;
        this.odgovori = odgovori;
    }

    public Pitanje(String naziv) {
        this.naziv = naziv;
    }

    public static Pitanje pitanjeDodaj(){
        return dodaj_pitanje;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Pitanje)) return false;
        Pitanje a=(Pitanje) obj;
        return a.getNaziv().equals(naziv);
    }

  public int getIndexOfTacan(){
        for(int i=0;i<odgovori.size();i++){
            if(odgovori.get(i).equals(tacan)) return i;
        }
        return -1;
  }

    public String getIdBaza() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
