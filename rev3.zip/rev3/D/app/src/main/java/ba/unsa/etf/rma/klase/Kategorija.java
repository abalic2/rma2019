package ba.unsa.etf.rma.klase;

import java.io.Serializable;

import ba.unsa.etf.rma.taskovi.IParselableBaza;

public class Kategorija implements Serializable,Pregled, IParselableBaza {
    private String naziv, id,idBaza;
    private static Kategorija svi=new Kategorija("Svi", "157","svi");
    private static int broj;
    private static Kategorija dodajKat=new Kategorija("Dodaj kategoriju", "671","dodaj");

    public Kategorija(String naziv, String id) {
        this.naziv = naziv;
        this.id = id;
    }

    public Kategorija(String naziv, String id, String idBaza) {
        this.naziv = naziv;
        this.id = id;
        this.idBaza = idBaza;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    @Override
    public boolean equals(Object obj) {
        Kategorija kategorija=(Kategorija) obj;
        return naziv.equals(kategorija.getNaziv());

    }
    public static int generisiId() {
        int broj1=broj;
        broj=(broj+1)%1000;
        return broj1;
    }

    public Kategorija() {
    }

    public void setId(String id) {
        this.id = id;
    }

    public static Kategorija kategorijaSvi(){
        return svi;
    }
    public static Kategorija kategorijaDodaj(){
        return dodajKat;
    }

    public String getIdBaza() {
        return idBaza;
    }

    public void setIdBaza(String idBaza) {
        this.idBaza = idBaza;
    }
}
