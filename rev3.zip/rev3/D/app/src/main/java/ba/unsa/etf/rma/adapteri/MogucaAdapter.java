package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.ItemAdapter;
import ba.unsa.etf.rma.klase.Pregled;

public class MogucaAdapter<Tip extends Pregled> extends ItemAdapter<Tip> {
    public MogucaAdapter(Context c, ArrayList<Tip> kvizovi) {
        super(c, kvizovi);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=getmInflater().inflate(R.layout.item_list,null);
        TextView nameTextView=(TextView)v.findViewById(R.id.textViewList);
        nameTextView.setTextColor(v.getResources().getColor(R.color.colorPrimaryDark));
        nameTextView.setText(getKvizovi().get(position).getNaziv());

        return v;
    }
}
