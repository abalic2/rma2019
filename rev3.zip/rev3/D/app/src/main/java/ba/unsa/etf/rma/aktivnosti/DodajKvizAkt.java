package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.ItemAdapter;
import ba.unsa.etf.rma.adapteri.MogucaAdapter;
import ba.unsa.etf.rma.adapteri.SpinAdapter;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizParser;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.PitanjaAsyncGet;
import ba.unsa.etf.rma.taskovi.QueryAsync;


public class DodajKvizAkt extends AppCompatActivity implements  PitanjaAsyncGet.OnPitanjeLoadDone, QueryAsync.QueryExecutor,
        AsyncPostPatch.OnUploaded {
    private ListView dodanaPitanja, mogucaPitanja;
    private TextView naziv;
    private Button dodajBtn, btnImportKviz;
    private Spinner spinner;
    private int pos = -1;
    private ArrayList<Pitanje> dodana = new ArrayList<>();
    private ItemAdapter<Pitanje> adapter;
    private MogucaAdapter<Pitanje> adapterMoguca;
    private ArrayList<Pitanje> moguca = new ArrayList<>();
    private DataAccessLayer dao = DataAccessLayer.getInstance();
    private Kviz kviz = new Kviz(), tmp=new Kviz();
    private boolean zahtjevProcessing=false;
    private SpinAdapter spAdapter;
    Kategorija dodanaKat=new Kategorija();
    private static final int READ_REQUEST_CODE = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);
        Intent in = getIntent();
        Bundle b = in.getExtras();

        dodanaPitanja = (ListView) findViewById(R.id.lvDodanaPitanja);
        mogucaPitanja = (ListView) findViewById(R.id.lvMogucaPitanja);
        naziv = (TextView) findViewById(R.id.etNaziv);
        spinner = (Spinner) findViewById(R.id.spKategorije);
        btnImportKviz = (Button) findViewById(R.id.btnImportKviz);

        spAdapter = new SpinAdapter(getBaseContext(), android.R.layout.simple_spinner_item, dao.getKategorije());
        spAdapter.addKategorijaEnd(Kategorija.kategorijaDodaj());
        spAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spAdapter);


        if (b != null) {
            pos = (int) b.getInt("pos");
            kviz = (Kviz) b.get("kviz");
            tmp = new Kviz(kviz.getNaziv(), kviz.getPitanja(), kviz.getKategorija());

            Kategorija kategorija = kviz.getKategorija();
            spinner.setSelection(spAdapter.getIndexOf(kategorija));
            naziv.setText(kviz.getNaziv());
        }

        new PitanjaAsyncGet(getInputStrm(), this, true).execute(new ArrayList<String>());

        dodajBtn = (Button) findViewById(R.id.btnDodajKviz);
        adapter = new ItemAdapter<>(getApplicationContext(), dodana);
        adapterMoguca = new MogucaAdapter<>(getApplicationContext(), moguca);
        dodanaPitanja.setAdapter(adapter);
        mogucaPitanja.setAdapter(adapterMoguca);

        btnImportKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String [] mimeTypes = {"text/csv", "text/plain","text/comma-separated-values"};
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
                startActivityForResult(intent, READ_REQUEST_CODE);

            }
        });

        dodajBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(zahtjevProcessing) return;
                boolean uredu = true;
                if (naziv.getText().length() == 0 ){
                    naziv.setBackgroundColor(getResources().getColor(R.color.colorRed));
                    uredu = false;
                }
                if (((Kategorija) spinner.getSelectedItem()).equals(Kategorija.kategorijaDodaj())) {
                    spinner.setBackgroundColor(getResources().getColor(R.color.colorRed));
                    uredu = false;
                }
                if (uredu) {
                    Intent intent = new Intent();
                    dodana.remove(Pitanje.pitanjeDodaj());
                    kviz.setPitanja(dodana);
                    kviz.setNaziv(naziv.getText().toString());
                    kviz.setKategorija((Kategorija) spinner.getSelectedItem());
                    zahtjevProcessing=true;


                    if(naziv.getText().toString().equals(tmp.getNaziv()) && pos>=0) {

                            dao.changeKviz(tmp, kviz, getInputStrm());
                             setResult(2, intent);
                             finish();

                    }
                    else new QueryAsync(getInputStrm(),getQueryExec()).execute(kviz);
                }
            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == spAdapter.getCount() - 1) {
                    Intent in = new Intent(getApplicationContext(), DodajKategorijuAkt.class);
                    startActivityForResult(in, 4);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        dodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == dodana.size() - 1) {
                    Intent intent = new Intent(getApplicationContext(), DodajPitanjeAkt.class);
                    kviz.setPitanja(dodana);
                    kviz.getPitanja().remove(Pitanje.pitanjeDodaj());
                    intent.putExtra("kviz",kviz);
                    intent.putExtra("pitanje", new Pitanje());
                    startActivityForResult(intent, 3);
                } else {
                    Pitanje a = dodana.get(position);
                    dodana.remove(position);
                    moguca.add(a);
                    adapter.notifyDataSetChanged();
                    adapterMoguca.notifyDataSetChanged();
                }

            }
        });

        mogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Pitanje a = moguca.get(position);
                moguca.remove(position);
                ArrayList<Pitanje> m = new ArrayList<>();
                m.add(a);
                dodajPitanjeUBuffer(m);
                adapter.notifyDataSetChanged();
                adapterMoguca.notifyDataSetChanged();

            }
        });
    }

    private void dodajPitanjeUBuffer(ArrayList<Pitanje> a) {
        dodana.remove(Pitanje.pitanjeDodaj());
        kviz.setPitanja(dodana);
        dodana.addAll(a);
        dodana.add(Pitanje.pitanjeDodaj());
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(!dodana.contains(Pitanje.pitanjeDodaj())) dodana.add(Pitanje.pitanjeDodaj());
        adapterMoguca.notifyDataSetChanged();
        adapter.notifyDataSetChanged();
        if (requestCode == 3 &&(  resultCode==3 || resultCode==0)) {
            if(resultCode==3) {
                Pitanje pitanjeInt = (Pitanje) data.getExtras().get("pitanje");
                dao.addPitanje(getInputStrm(), pitanjeInt);
                dodana.remove(Pitanje.pitanjeDodaj());
                dodana.add(pitanjeInt);
                dodana.add(Pitanje.pitanjeDodaj());
            }
            moguca.clear();
            ArrayList<Pitanje> buf = dao.getPitanja();
            buf.removeAll(dodana);
            moguca.addAll(buf);
            adapter.notifyDataSetChanged();
            adapterMoguca.notifyDataSetChanged();

        } else if (resultCode == 4 && requestCode == 4) {
            Kategorija kategorija = (Kategorija) data.getExtras().get("kategorija");
            dodajKategoriju(kategorija);
        } else if (requestCode == 4) {
            spinner.setSelection(spAdapter.getIndexOf(Kategorija.kategorijaSvi()));
        } else if (requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Uri uri = null;
            if (data != null) {
                uri = data.getData();
                try {
                    importujKviz(uri);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private void importujKviz(Uri uri) throws FileNotFoundException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        KvizParser parser=new KvizParser(this);
        Kviz parsed=parser.importujKviz(inputStream);
        if(parsed!=null) {
            String nazivK=parsed.getKategorija().getNaziv();
            if (!dao.nalaziSeKategorija(nazivK))
                dodajKategoriju(new Kategorija(nazivK, Kategorija.generisiId() + ""));
            spinner.setSelection(spAdapter.getIndexOf(nazivK));
            naziv.setText(parsed.getNaziv());
            dodana.clear();
            dodajPitanjeUBuffer(parsed.getPitanja());
            adapter.notifyDataSetChanged();
        }
    }

    private void dodajKategoriju(Kategorija kategorija) {


        dao.addKategorija(kategorija);
        spAdapter.setValues(dao.getKategorije());
        dodanaKat=kategorija;
        spAdapter.addKategorijaEnd(Kategorija.kategorijaDodaj());
        spAdapter.notifyDataSetChanged();
        spinner.setSelection(spAdapter.getIndexOf(kategorija));
        dao.addKategorijaBaza(kategorija, getInputStrm());



    }

    private InputStream getInputStrm(){
        return getResources().openRawResource(R.raw.secret);
    }


    @Override
    public void onPitanjaLoaded(ArrayList<Pitanje> pitanjas) {

        dao.setPitanja(pitanjas);
        ArrayList<Pitanje> postojeca=kviz.getPitanja();
      if(postojeca!=null && postojeca.size()>0){
      ArrayList<String> idPitanja=new ArrayList<>();
      for(Pitanje a: postojeca){
          idPitanja.add(a.getIdBaza());
      }
      for(Pitanje a: pitanjas){

          if(idPitanja.contains(a.getIdBaza())){
              dodana.add(a);
          }
          else moguca.add(a);
      }
      kviz.setPitanja(dodana);

  }
  else {
          moguca.clear();
          moguca.addAll(pitanjas);
      }
  dodana.add(Pitanje.pitanjeDodaj());
  adapterMoguca.notifyDataSetChanged();
  adapter.notifyDataSetChanged();

    }

    @Override
    public void onQueryExecuted(String rezultat) {

            Boolean vrijednost = parseQuery(rezultat);
            zahtjevProcessing = false;
            Intent intent = new Intent();
            if (vrijednost) {
                alertDialog("Uneseni kviz već postoji!");
                naziv.setBackgroundColor(getResources().getColor(R.color.colorRed));

            } else {
                if (pos >= 0) {

                    dao.changeKviz(tmp, kviz, getInputStrm());

                } else {
                    Log.d("desi se4", "onUploadDone: ");
                    dao.removeKviz(Kviz.dodajNovi());
                    dao.addKviz(getInputStrm(), kviz);
                    dao.addKviz(Kviz.dodajNovi());
                }
                setResult(2,intent);
                finish();

            }

    }

    private Boolean parseQuery(String rezultat) {
        if(rezultat.contains(kviz.getNaziv())) return true;
        return false;

    }

    private void alertDialog(String text) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setMessage(text);
        dialog.setTitle("Upozorenje");
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                    }
                });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }
    private QueryAsync.QueryExecutor getQueryExec(){
        return this;
    }

    @Override
    public void onUploadDone(IParselableBaza object, String id) {

    }
}
