package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.ItemAdapter;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;

public class ListaFrag extends Fragment {

    private OnFragmentInteractionListener mListener;
    private ListView listView;
    private DataAccessLayer dao=DataAccessLayer.getInstance();
    private ItemAdapter<Kategorija> adapter;

    public ListaFrag() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_lista, container, false);
        return v;
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        listView=(ListView)getView().findViewById(R.id.listaKategorija);
        adapter = new ItemAdapter<Kategorija>(getActivity(), dao.getKategorije());
        adapter.addData(Kategorija.kategorijaSvi());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mListener.onFragmentInteraction(position);
            }
        });

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;


        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public void dataSetChanged(){
        if(adapter!=null) adapter.notifyDataSetChanged();

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(int kategorija);
    }
}
