package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pregled;

public class ItemAdapter<Tip extends Pregled> extends BaseAdapter {
   private ArrayList<Tip> kvizovi;
   private LayoutInflater mInflater;

    public ArrayList<Tip> getKvizovi() {
        return kvizovi;
    }

    public LayoutInflater getmInflater() {
        return mInflater;
    }

    private Context c;
    public ItemAdapter(Context c, ArrayList<Tip> kvizovi) {
        this.kvizovi = kvizovi;
        this.c=c;
        mInflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
    @Override
    public int getCount() {
        return kvizovi.size();
    }
    public void addData(Tip k){

        if(!kvizovi.contains(k)) kvizovi.add(k);
    }
    public void setData(ArrayList<Tip> d){
        kvizovi=d;
    }


    @Override
    public Object getItem(int position) {
        return kvizovi.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=mInflater.inflate(R.layout.item_list,null);

        final IconHelper iconHelper = IconHelper.getInstance(mInflater.getContext());
        TextView nameTextView=(TextView)v.findViewById(R.id.textViewList);
        nameTextView.setTextColor(v.getResources().getColor(R.color.colorPrimaryDark));
        nameTextView.setText(kvizovi.get(position).getNaziv());
        final ImageView img=(ImageView)v.findViewById(R.id.imageViewIcon) ;

final int pos=position;

 if(kvizovi.get(position) instanceof Kategorija){
            iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                @Override
                public void onDataLoaded() {
                    int id=Integer.parseInt(((Kategorija) kvizovi.get(pos)).getId());
                    img.setImageDrawable(iconHelper.getIcon(id).getDrawable(mInflater.getContext()));
                }
            });

        }
        else {
     if (position == kvizovi.size() - 1) {
         img.setImageResource(R.drawable.add_icon);
     } else if (kvizovi.get(position) instanceof Kviz) {

         iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
             @Override
             public void onDataLoaded() {
                 int id = Integer.parseInt(((Kviz) kvizovi.get(pos)).getKategorija().getId());
                 img.setImageDrawable(iconHelper.getIcon(id).getDrawable(mInflater.getContext()));

             }
         });
     }
 }

        return v;
    }
}





