package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;

import java.io.InputStream;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.ItemAdapter;
import ba.unsa.etf.rma.adapteri.SpinAdapter;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.RangIgrac;
import ba.unsa.etf.rma.klase.RangPodaci;
import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.QueryAsync;
import ba.unsa.etf.rma.taskovi.TaskExec;


public class KvizoviAkt extends AppCompatActivity implements ListaFrag.OnFragmentInteractionListener,DataAccessLayer.DataLoader, AsyncPostPatch.OnUploaded,
        QueryAsync.QueryExecutor

{
    private DataAccessLayer dao= DataAccessLayer.getInstance();
    private Spinner spinner;
    private SpinAdapter spAdapter;
    private ItemAdapter adapter;
    private Boolean siril=false;
    private  ListaFrag listaFrag;
    private  RangPodaci rp;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        FragmentManager fm=getSupportFragmentManager();
        FrameLayout listPlace=(FrameLayout) findViewById(R.id.listPlace);
        if(listPlace!=null){
            siril=true;

            listaFrag=(ListaFrag) fm.findFragmentById(R.id.listPlace);
            if(listaFrag==null){
                listaFrag=new ListaFrag();
                fm.beginTransaction().replace(R.id.listPlace, listaFrag).commit();
            }

            onFragmentInteraction(0);
        }
        dao.setPozivatelj(this);
         if(!siril) {
             ListView quizList = (ListView) findViewById(R.id.lvKvizovi);
             spinner = (Spinner) findViewById(R.id.spPostojeceKategorije);
             spAdapter = new SpinAdapter(getBaseContext(), android.R.layout.simple_spinner_item,dao.getKategorijeBaza(getInputStrm()));
             spAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
             spinner.setAdapter(spAdapter);
             adapter = new ItemAdapter<Kviz>(this,  dao.getKvizovi());
             adapter.addData(Kviz.dodajNovi());
             quizList.setAdapter(adapter);
             spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                 @Override
                 public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {

                     adapter.setData(promjenaKat());
                     adapter.notifyDataSetChanged();
                 }

                 @Override
                 public void onNothingSelected(AdapterView<?> parent) {

                 }
             });
             quizList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

                                                     @Override
                                                     public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                                                         Intent showDetailActivity = new Intent(getApplicationContext(), DodajKvizAkt.class);
                                                         if (position != dao.getKvizovi().size() - 1) {
                                                             //bilo position!=promjenaKat().size()-1
                                                            // showDetailActivity.putExtra("kviz", promjenaKat().get(position));
                                                             new QueryAsync(getInputStrm(),getQueryExec()).execute(new RangPodaci(dao.getKvizovi().get(position).getNaziv(),new ArrayList<RangIgrac>()));
                                                             showDetailActivity.putExtra("kviz", dao.getKvizovi().get(position));
                                                             showDetailActivity.putExtra("pos", position);
                                                         }
                                                         startActivityForResult(showDetailActivity, 2);
                                                         return true;
                                                     }
                                                 }
             );

             quizList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                 @Override
                 public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                     if (position == dao.getKvizovi().size() - 1) return;
                     Intent in = new Intent(getApplicationContext(), IgrajKvizAkt.class);
                    // in.putExtra("kviz", promjenaKat().get(position));
                     in.putExtra("kviz", dao.getKvizovi().get(position));
                     startActivityForResult(in,5);
                 }
             });
         }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Vratula se", "onActivityResult: ");
        if(siril ){

            if(listaFrag!=null) listaFrag.dataSetChanged();
            return;
        }

        spAdapter.setValues(dao.getKategorijeBaza(getInputStrm()));
        spAdapter.notifyDataSetChanged();

         if(resultCode!=2) adapter.setData(promjenaKat());
            adapter.notifyDataSetChanged();
        }


    private ArrayList<Kviz> promjenaKat() {
       //na osnovu izabrane
      if(!siril)  dao.getKvizoviBaza(getInputStrm(), (Kategorija) spinner.getSelectedItem());
      return dao.getKvizovi();
    }

    @Override
    public void onFragmentInteraction(int kategorija) {
        Bundle args=new Bundle();
        args.putInt("position", kategorija);
        DetailFrag details=new DetailFrag();
        details.setArguments(args);
        if(siril){
            getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace,details).commit();
        }
    }

    @Override
    public void onDataLoaded(String idDokKategorije) {
        if(idDokKategorije.equals("kategorije")){
            spAdapter.setValues(dao.getKategorije());
            spAdapter.notifyDataSetChanged();
        }
        if(idDokKategorije.equals("kviz")){

            adapter.setData(dao.getKvizovi());
            adapter.addData(Kviz.dodajNovi());
            adapter.notifyDataSetChanged();
        }
        else if(idDokKategorije.equals("kvizUpload")){
            promjenaKat();
        }
        else if(idDokKategorije.contains("Kviz change")){
            Log.d("promjena", "onDataLoaded: ");
            String[] nazivi=idDokKategorije.split(",");
          if(rp!=null)  {
              rp.setNaziv(nazivi[1]);
              new AsyncPostPatch(getInputStrm(),"PATCH", this).execute(rp);
          }
        }
    }

    private InputStream getInputStrm(){
      return getResources().openRawResource(R.raw.secret);
    }

    @Override
    public void onUploadDone(IParselableBaza object, String id) {

    }

    private QueryAsync.QueryExecutor getQueryExec(){
        return this;
    }
    @Override
    public void onQueryExecuted(String vrijednost) {
        rp= TaskExec.parseRang(vrijednost);
    }
}
