package ba.unsa.etf.rma.klase;


import java.io.InputStream;
import java.util.ArrayList;

import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.KategorijaGet;
import ba.unsa.etf.rma.taskovi.KvizAsyncGet;

public class DataAccessLayer implements AsyncPostPatch.OnUploaded ,KategorijaGet.OnKategorijaLoaded, KvizAsyncGet.OnKvizoviLoaded{

    private static final DataAccessLayer ourInstance = new DataAccessLayer();
    private ArrayList<Kviz> kvizovi=new ArrayList<>();
    private ArrayList<Kategorija> kategorije=new ArrayList<>();
    private ArrayList<Pitanje> pitanja = new ArrayList<>();
    private DataLoader pozivatelj;
    

    @Override
    public void onDoneKviz(ArrayList<Kviz> kvizovi) {
        this.kvizovi=kvizovi;
        pozivatelj.onDataLoaded("kviz");


    }

    @Override
    public void onUploadDone(IParselableBaza object, String id) {

        if(object instanceof Kviz) {
            pozivatelj.onDataLoaded("kvizUpload");
        }
    }

    public interface DataLoader{
        void onDataLoaded(String type);
    }

    public void setPozivatelj(DataLoader pozivatelj) {
        this.pozivatelj = pozivatelj;
    }

    public static DataAccessLayer getInstance() {
        return ourInstance;
    }

    private DataAccessLayer() {

    }

    public ArrayList<Kviz> getKvizovi() {
        return kvizovi;
    }
    public ArrayList<Kviz> getKvizoviBaza(InputStream is, Kategorija kategorija) {

        new KvizAsyncGet(is,this).execute(kategorija);
        return kvizovi;
    }

    public void addPitanje(InputStream stream, Pitanje pitanje){
        new AsyncPostPatch(stream,"POST",this).execute(pitanje);
        pitanja.add(pitanje);

    }

    public void setKvizovi(ArrayList<Kviz> kvizovi) {
        this.kvizovi = kvizovi;
    }

    public ArrayList<Kategorija> getKategorije() {
       return kategorije;
    }

    public ArrayList<Kategorija> getKategorijeBaza(InputStream stream) {

        new KategorijaGet(stream, this).execute("sve");

       return kategorije;
    }


    public void setKategorije(ArrayList<Kategorija> kategorije) {
        this.kategorije = kategorije;
    }

    public void addKviz(Kviz kviz){
       kvizovi.add(kviz);
    }

    public void addKviz(InputStream stream, Kviz kviz){

        kvizovi.add(kviz);
        new AsyncPostPatch(stream,"POST",this).execute(kviz);

    }
    
    

    public void addKategorija(Kategorija kategorija){

       if(!kategorije.contains(kategorija)) kategorije.add(kategorija);
    }

    public void addKategorijaBaza(Kategorija kategorija, InputStream stream){


        new AsyncPostPatch(stream,"POST",this).execute(kategorija);
    }
    public void removeKategorija(Kategorija kategorija){
        kategorije.remove(kategorija);
    }

    public void changeKviz(Kviz prvi, Kviz kviz, InputStream stream){

        int index=-1;
       for(int i=0;i<kvizovi.size();i++){
           if(kvizovi.get(i).equals(prvi)) index=i;
       }
      if(index>=0) {
          kvizovi.remove(index);
          kvizovi.add(index, kviz);
      }
        pozivatelj.onDataLoaded("Kviz change,"+kviz.getNaziv());
        new AsyncPostPatch(stream,"PATCH",this).execute(kviz);


    }

    public void removeKviz(Kviz kviz){
        kvizovi.remove(kviz);
    }
    public boolean nalaziSeKviz(String ime) {

        for (Kviz a : kvizovi) {
            if (a.getNaziv().equals(ime)) return true;
        }
        return false;
    }
    public boolean nalaziSeKategorija(String ime) {

        for (Kategorija a : kategorije) {
            if (a.getNaziv().equals(ime)) return true;
        }
        return false;
    }

    public Kategorija dajKategoriju(String id) {

        for (Kategorija a : kategorije) {
            if (a.getIdBaza().equals(id)) return a;
        }
        return null;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    @Override
    public void onDone(ArrayList<Kategorija> kategorijas) {

        kategorije=kategorijas;
        pozivatelj.onDataLoaded("kategorije");

    }


}
