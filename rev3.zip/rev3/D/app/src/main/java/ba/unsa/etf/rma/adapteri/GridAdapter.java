package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pregled;

public class GridAdapter<Tip extends Pregled> extends BaseAdapter {
    private ArrayList<Tip> items;
    private LayoutInflater mInflater;

    private Context c;
    public GridAdapter(Context c, ArrayList<Tip> items) {
        this.items = items;
        this.c=c;
        mInflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return items.size();
    }
    public void addData(Tip k){

        if(!items.contains(k)) items.add(k);
    }
    public void setData(ArrayList<Tip> d){
        items=d;
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.grid_item, null);

        final IconHelper iconHelper = IconHelper.getInstance(mInflater.getContext());

        TextView nameTextView = (TextView) v.findViewById(R.id.grid_naziv);
        final TextView numQuestions = (TextView) v.findViewById(R.id.grid_br_pitanja);
        nameTextView.setText(items.get(position).getNaziv());
        final ImageView img = (ImageView) v.findViewById(R.id.img_grid);
        final int pos=position;
        if(position==items.size()-1){img.setImageResource(R.drawable.add_icon);}
        else if( items.get(position) instanceof Kviz){

            iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                @Override
                public void onDataLoaded() {
                    int id=Integer.parseInt(((Kviz) items.get(pos)).getKategorija().getId());
                    numQuestions.setText(((Kviz) items.get(pos)).getPitanja().size()+"");
                    img.setImageDrawable(iconHelper.getIcon(id).getDrawable(mInflater.getContext()));

                }
            });
        }

        return v;
    }
}
