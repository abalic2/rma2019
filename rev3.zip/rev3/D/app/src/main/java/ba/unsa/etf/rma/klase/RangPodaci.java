package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import ba.unsa.etf.rma.taskovi.IParselableBaza;

public class RangPodaci implements IParselableBaza, Serializable {
    private String  id="", nazivKviza;
    private ArrayList<RangIgrac> igraci=new ArrayList<>();

    public RangPodaci() {
    }

    class Sortbyroll implements Comparator<RangIgrac>
    {
        public int compare(RangIgrac a, RangIgrac b)
        {
            return a.getPozicija() - b.getPozicija();
        }
    }

    public RangPodaci(String nazivKviza, ArrayList<RangIgrac> igraci) {
        this.nazivKviza = nazivKviza;
        this.igraci = igraci;
        Collections.sort(this.igraci, new Sortbyroll());
    }

    public ArrayList<RangIgrac> getIgraci() {
        return igraci;
    }

    public void setIgraci(ArrayList<RangIgrac> igraci) {
        this.igraci = igraci;
        Collections.sort(this.igraci, new Sortbyroll());
    }
    public void addIgrac(RangIgrac igr){
       if(igraci==null) igraci=new ArrayList<>();
        int pos=igraci.size();
        for(int i=0;i<igraci.size();i++){
            if(igraci.get(i).getProcenatTacnih()<igr.getProcenatTacnih()){ pos=i; break;}
        }
        igraci.add(pos,igr);
        for(int i=pos;i<igraci.size();i++){
            igraci.get(i).setPozicija(i+1);
        }

    }

    public String getIdBaza() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getNaziv() {
        return nazivKviza;
    }

    public void setNaziv(String nazivKviza) {
        this.nazivKviza = nazivKviza;
    }
}
