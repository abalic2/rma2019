package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.KvizAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviAkt extends AppCompatActivity {
    Spinner spPostojeceKategorije;
    ListView lvKvizovi;
    ArrayList<Kategorija> kategorija;
    ArrayList<Pitanje> pitanje;
    ArrayList<Kviz> kviz;
    ArrayList<Kviz> filtrirane;
    Kviz univerzalni = new Kviz("Dodaj Kviz",new Kategorija("DodajKviz","DodajKviz666"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);

        //Activity_kvizovi_akt.xml povezivanje elemenata sa programom
        spPostojeceKategorije = findViewById(R.id.spPostojeceKategorije);
        lvKvizovi = findViewById(R.id.lvKvizovi);

        //Incijaliziranje i stavljanje adaptera
        kategorija = new ArrayList<>();
        kategorija.add(new Kategorija("Svi", "0"));
        spPostojeceKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,dajSveKategorije(kategorija)));
        pitanje = new ArrayList<>();
        kviz = new ArrayList<>();



        lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,dajKvizoveKategorije("Svi")));
        //Mjenjanje kategorije u spineru i filtriranje u listView
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i>=0 && i<kategorija.size()){
                    pretraziKvizove(i);
                }
                else{
                    Toast.makeText(KvizoviAkt.this, "Nema Kategorije", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("Kviz", filtrirane.get(i));
                bundle.putSerializable("Kategorije",kategorija);
                bundle.putSerializable("Pitanja",pitanje);
                bundle.putSerializable("Kvizovi",kviz);
                Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                intent.putExtra("Bundle",bundle);
                startActivityForResult(intent,102);
            }
        });

    }
    //FUNKCIJE
    public ArrayList<String> dajSveKategorije(ArrayList<Kategorija> x){
        ArrayList<String> sveKategorije = new ArrayList<>();
        for(int i=0; i<x.size(); i++){
            sveKategorije.add(x.get(i).getNaziv());
        }
        return sveKategorije;
    }


    public ArrayList<Kviz> dajKvizoveKategorije(String x){
        ArrayList<Kviz> sviKvizoviKategorije = new ArrayList<>();
        Kategorija tempKategorija = new Kategorija("Greska","-987654321");
        for(int i=0; i<kategorija.size(); i++){
            if(kategorija.get(i).getNaziv().equals(x)){
                tempKategorija = kategorija.get(i);
                break;
            }
        }
        if(tempKategorija.getId().equals("0")){
            for(int i=0; i<kviz.size(); i++){
                sviKvizoviKategorije.add(kviz.get(i));
            }
        }
        else{
            for(int i=0; i<kviz.size(); i++){
                if(kviz.get(i).getKategorija().getNaziv().equals(tempKategorija.getNaziv())
                        && kviz.get(i).getKategorija().getId().equals(tempKategorija.getId())){
                    sviKvizoviKategorije.add(kviz.get(i));
                }
            }
        }
        sviKvizoviKategorije.add(univerzalni);
        return sviKvizoviKategorije;

    }

    public void pretraziKvizove(int i){
        ArrayList<String> kategorijeString = dajSveKategorije(kategorija);
        String tempKategorijaString = kategorijeString.get(i);
        filtrirane = dajKvizoveKategorije(tempKategorijaString);
        lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,filtrirane));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        if (resultCode == 201) {
            kviz = (ArrayList<Kviz>) data.getBundleExtra("Bundle").getSerializable("Kvizovi");
            kategorija = (ArrayList<Kategorija>) data.getBundleExtra("Bundle").getSerializable("Kategorije");
            pitanje = (ArrayList<Pitanje>) data.getBundleExtra("Bundle").getSerializable("Pitanja");
            spPostojeceKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,dajSveKategorije(kategorija)));
            lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,dajKvizoveKategorije("Svi")));

        }
    }
}
