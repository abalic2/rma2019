package ba.unsa.etf.rma.asyncKlase;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKategorijuAkt;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DobaviIdKvizaIzBaze extends AsyncTask<String, Void, Void>{
    String linkID = "";
    ArrayList<Kviz> rezultatAsyncKlase = new ArrayList<>();
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    private IDobaviIdKvizaIzBaze pozivatelj;

    public DobaviIdKvizaIzBaze(IDobaviIdKvizaIzBaze p){
        pozivatelj = p;
    }

    @Override
    protected Void doInBackground(String... strings){
        Context x = DodajKvizAkt.context;
        try {
            InputStream is = x.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            String url = "https://firestore.googleapis.com/v1/projects/rma-moj-projekat/databases/(default)/documents/Kvizovi?access_token=";
            URL urlConnection = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection connection = (HttpURLConnection) urlConnection.openConnection();

            int responseCode = connection.getResponseCode();
            if(responseCode == HttpURLConnection.HTTP_OK){
                try(BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))){
                    StringBuilder res = new StringBuilder();
                    String line = null;
                    while((line = br.readLine()) != null){
                        res.append(line.trim());
                    }
                    //Odgovor od stranice pretvaramo u String
                    String rezultat = res.toString();
                    //Taj odgovor pretvaramo u JSON objekat
                    JSONObject jo = new JSONObject(rezultat);
                    //Prvi u formatu je documents koji je tipa Array
                    JSONArray jo_documents = jo.getJSONArray("documents");
                    //Sljedeci u formatu je name koji je tipa Object ali posto imamo array moramo for petljom dobavljati sve objekte
                    for(int i = 0; i<jo_documents.length(); i++){
                        JSONObject jo_Object = jo_documents.getJSONObject(i);
                        String jox = jo_Object.getString("name");
                        String finalLink = jox.substring(63);

                        JSONObject jo_fields = jo_Object.getJSONObject("fields");
                        JSONObject jo_naziv = jo_fields.getJSONObject("naziv");
                        String naziv = jo_naziv.get("stringValue").toString();

                        if(naziv.equals(strings[0])) linkID = finalLink;
                    }

                }finally {
                    connection.disconnect();
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }


    public interface IDobaviIdKvizaIzBaze{
        public void onDobaviIdKvizaIzBaze(String linkID);
    }

    @Override
    protected void onPostExecute(Void aVoid){
        super.onPostExecute(aVoid);
        pozivatelj.onDobaviIdKvizaIzBaze(linkID);
    }

}
