package ba.unsa.etf.rma.aktivnosti;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.asyncKlase.DohvatiSvaPitanja;
import ba.unsa.etf.rma.asyncKlase.DohvatiSveKategorije;
import ba.unsa.etf.rma.asyncKlase.PostajPitanje;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity implements DohvatiSvaPitanja.IDohvatiSvaPitanja, PostajPitanje.IPostajPitanje {
    public static Context context;
    ListView lvOdgovori;
    EditText etNaziv;
    EditText etOdgovor;
    Button btnDodajOdgovor;
    Button btnDodajTacan;
    Button btnDodajPitanje;

    Kviz kviz;
    ArrayList<Kviz> kvizovi;
    ArrayList<Pitanje> pitanja;

    ArrayList<String> odgovori;
    String tacanOdgovor = "?x?";
    int tacanIndex = -1;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);
        context = this;
        new DohvatiSvaPitanja((DohvatiSvaPitanja.IDohvatiSvaPitanja)DodajPitanjeAkt.this).execute("proba4");

        kviz = (Kviz) getIntent().getBundleExtra("Bundle").getSerializable("Kviz");
        kvizovi = (ArrayList<Kviz>) getIntent().getBundleExtra("Bundle").getSerializable("Kvizovi");
        pitanja = (ArrayList<Pitanje>) getIntent().getBundleExtra("Bundle").getSerializable("Pitanja");

        lvOdgovori = findViewById(R.id.lvOdgovori);
        odgovori = new ArrayList<>();
        postaviAdapterOdgovora();

        etNaziv = findViewById(R.id.etNaziv);
        etOdgovor = findViewById(R.id.etOdgovor);

        btnDodajOdgovor = findViewById(R.id.btnDodajOdgovor);

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etOdgovor.getText().toString().trim().equals("")){
                    etOdgovor.setBackgroundColor(getResources().getColor(R.color.boja1));
                }
                else{
                    etOdgovor.setBackgroundColor(Color.WHITE);
                    Boolean postoji = false;
                    for(int i=0; i< odgovori.size();i++){
                        if(odgovori.get(i).equals(etOdgovor.getText().toString().trim())){
                            postoji = true;
                        }
                    }
                    if(!postoji){
                        odgovori.add(etOdgovor.getText().toString());
                        postaviAdapterOdgovora();
                        etOdgovor.setText("");
                    }
                    else{
                        etOdgovor.setText("");
                        etOdgovor.setBackgroundColor(getResources().getColor(R.color.boja1));
                    }
                }
            }
        });

        btnDodajTacan = findViewById(R.id.btnDodajTacan);

        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Boolean postoji = false;
                for(int i=0; i< odgovori.size();i++){
                    if(odgovori.get(i).equals(etOdgovor.getText().toString().trim())){
                        postoji = true;
                    }
                }
                if(etOdgovor.getText().toString().trim().equals("") || etOdgovor.getText() == null) postoji = true;
                if(!postoji){
                    etOdgovor.setBackgroundColor(Color.WHITE);
                    tacanOdgovor = etOdgovor.getText().toString();
                    odgovori.add(tacanOdgovor);
                    tacanIndex = odgovori.size()-1;
                    btnDodajTacan.setEnabled(false);
                    postaviAdapterOdgovora();
                }
                else{
                    etOdgovor.setText("");
                    etOdgovor.setBackgroundColor(getResources().getColor(R.color.boja1));
                }

            }
        });

        btnDodajPitanje = findViewById(R.id.btnDodajPitanje);

        btnDodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean jedinstvenKviz = true;
                Boolean mozeMoze = true;

                for(int i=0; i<pitanja.size(); i++){
                    if(pitanja.get(i).getNaziv().equals(etNaziv.getText().toString().trim())){
                        jedinstvenKviz = false;
                    }
                }
                if(etNaziv.getText().toString().trim().equals("") || etNaziv.getText() == null) jedinstvenKviz = false;

                if(!jedinstvenKviz){
                    mozeMoze = false;
                    etNaziv.setText("");
                    etNaziv.setBackgroundColor(getResources().getColor(R.color.boja1));
                }
                if(tacanIndex == -1){
                    lvOdgovori.setBackgroundColor(getResources().getColor(R.color.boja1));
                    btnDodajTacan.setBackgroundColor(getResources().getColor(R.color.boja1));
                    mozeMoze = false;
                }

                if(mozeMoze){
                    Pitanje novoPitanje = new Pitanje(etNaziv.getText().toString(),etNaziv.getText().toString(),odgovori,tacanOdgovor);
                    for(int i=0; i<kvizovi.size(); i++){
                        if(kvizovi.get(i).getNaziv().equals(kviz.getNaziv())){
                            kvizovi.get(i).dodajPitanje(novoPitanje);
                            kviz = kvizovi.get(i);
                            break;
                        }
                    }
                    pitanja.add(novoPitanje);
                    String[] ex = new String[2+odgovori.size()];
                    ex[0] = etNaziv.getText().toString();
                    ex[1] = tacanIndex+"";
                    for(int i=0; i<odgovori.size(); i++){
                        ex[2+i] = odgovori.get(i);
                    }
                    new PostajPitanje(DodajPitanjeAkt.this).execute(ex);
                }


            }
        });

        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(tacanIndex == -1){
                    if(i>=0 && i<odgovori.size()){
                        odgovori.remove(i);
                        postaviAdapterOdgovora();
                    }
                }
                else{
                    if(i>=0 && i<odgovori.size()){
                        if(tacanIndex == i){
                            tacanIndex = -1;
                            tacanOdgovor = "?x?";
                            btnDodajTacan.setEnabled(true);
                        }
                        else if(tacanIndex>i){
                            tacanIndex--;
                        }
                        odgovori.remove(i);
                        postaviAdapterOdgovora();
                    }
                }
            }
        });


    }


    public void postaviAdapterOdgovora() {
        lvOdgovori.setAdapter(new ArrayAdapter<>(DodajPitanjeAkt.this, android.R.layout.simple_list_item_1, odgovori));
    }

    @Override
    public void onDohvatiSvaPitanja(ArrayList<Pitanje> rezultat) {
        pitanja=rezultat;
    }

    @Override
    public void onPostajPitanje() {
        Bundle bundle = new Bundle();
        bundle.putSerializable("Kvizovi", kvizovi);
        bundle.putSerializable("Pitanja",pitanja);
        bundle.putSerializable("Kviz",kviz);
        Intent intent = new Intent();
        intent.putExtra("Bundle",bundle);
        setResult(302,intent);
        finish();
    }
}

