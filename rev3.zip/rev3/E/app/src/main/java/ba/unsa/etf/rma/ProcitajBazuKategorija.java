package ba.unsa.etf.rma;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;

public class ProcitajBazuKategorija extends AsyncTask<String, Void, Void> {

    private Context con;
    private ArrayList<Kategorija> kategorije= new ArrayList<>();
    private ArrayList<String> dokumentKategorija = new ArrayList<>();

    public ProcitajBazuKategorija(Context c, ArrayList<Kategorija> k, ArrayList<String> s) {
        con = c;
        kategorije = k;
        dokumentKategorija = s;
    }

    @Override
    protected Void doInBackground(String... strings) {

        /*

        GoogleCredential credentials;
        try {
            InputStream tajnaStream = con.getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/projekatspirala/databases/(default)/documents/Kategorije?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN,"UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) !=null ) {
                    response.append(responseLine.trim() + "\n");
                }
                String inputStream = response.toString();
                try {
                    JSONObject jo = new JSONObject(inputStream);
                    JSONArray dokumenti = jo.getJSONArray("documents");
                    for (int i=0; i< dokumenti.length(); i++) {
                        JSONObject kata = dokumenti.getJSONObject(i);
                        String str = kata.getString("name");
                        String[] dijelovi = str.split("/");
                        String dokumentId = dijelovi[6];
                        JSONObject konkretnaKata = kata.getJSONObject("fields");
                        JSONObject nazivKate = konkretnaKata.getJSONObject("naziv");
                        JSONObject idKate = konkretnaKata.getJSONObject("idIkonice");
                        String n = nazivKate.getString("stringValue");
                        String id = idKate.getString("integerValue");
                        boolean postojiKategorija = false;
                        for (int j=0; j<kategorije.size(); j++) {
                            if (kategorije.get(j).getNaziv().equals(n) || kategorije.get(j).getId().equals(id))
                                postojiKategorija = true;
                        }
                        if (!postojiKategorija) {
                            kategorije.add(new Kategorija(n, id));
                            dokumentKategorija.add(dokumentId);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            conn.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }

        */
        return null;
    }
}
