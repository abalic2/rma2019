package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.app.FragmentManager;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.adapteri.AdapterSpinerKategorijaNaziv;
import ba.unsa.etf.rma.intentSevisi.intsDajKvizoveIzOdabraneKategorije;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKategorijeSveKvizoveSvaPitanja;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKvizoveIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsNapuniBazuPocetnimVrijednostima;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.adapteri.AdapterListaKvizova;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.KadKlikneNaKategoriju, resultReceiverZaSveIntentServise.Receiver
{
    //ATRIBUTI
    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;

    private AdapterListaKvizova adapterKvizovi;
    private ArrayList<Kviz> alSviKvizovi = new ArrayList<>();
    private ArrayList<Kviz> alFiltriraniKvizovi = new ArrayList<>();
    private View footerView;

    private AdapterSpinerKategorijaNaziv adapterSpinerKategorijaNaziv;
    private ArrayList<Kategorija> alSveKategorije = new ArrayList<>();
    final Kategorija kategorijaSve = new Kategorija("Svi", "0");
    private boolean prviPutSeDobavljaSveIzBaze;

    private ArrayList<Pitanje> alSvaPitanja = new ArrayList<>();

    boolean sirina550 = false;

    private String tokenZaBazu;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //napuni();

        if(jeLiPovratakIzKviza() == false)
            alSveKategorije.add(kategorijaSve);

        FragmentManager fragmentManager = getFragmentManager();
        FrameLayout flListaPlace = (FrameLayout) findViewById(R.id.listPlace);

        //znaci da je dovoljno velik ekran
        if(flListaPlace != null)
        {
            reagujNaPovratakIzDodajKvizAkt();
            sirina550 = true;

            ListaFrag listaFrag;
            listaFrag = (ListaFrag) fragmentManager.findFragmentById(R.id.listPlace);

            if(listaFrag == null)
            {
                //kreiramo novi fragment ListaFrag ukoliko već nije kreiran
                listaFrag = new ListaFrag();

                Bundle bundleListaFrag = new Bundle();
                bundleListaFrag.putSerializable("sveKategorije",alSveKategorije);
                bundleListaFrag.putSerializable("sviKvizovi", alSviKvizovi);
                bundleListaFrag.putSerializable("svaPitanja", alSvaPitanja);
                listaFrag.setArguments(bundleListaFrag);

                fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commit();

                //DRUGI FRAGMENT
                DetailFrag detailFrag;
                detailFrag = (DetailFrag) fragmentManager.findFragmentById(R.id.detailPlace);

                //kreiramo novi fragment DetaliFrag ako vec nije kreiran
                if(detailFrag == null)
                {
                    detailFrag = new DetailFrag();
                    Bundle bundleDetailFrag = new Bundle();

                    //OVJDE DODATI DA SE NA POCETKU PRIKAZU PODACI O FIKTIVNOM KVIZU "Svi" PRI PRIKAZU NA EKRANU 500dp ILI VISE
                    bundleDetailFrag.putSerializable("sveKategorije",alSveKategorije);
                    bundleDetailFrag.putSerializable("sviKvizovi", alSviKvizovi);
                    bundleDetailFrag.putSerializable("svaPitanja", alSvaPitanja);
                    bundleDetailFrag.putSerializable("selektovana kategorija", kategorijaSve);

                    detailFrag.setArguments(bundleDetailFrag);
                    fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
                }
            }
        }
        else
        {
            //NE MOZE SE SVE OVO IZBACITI I POZVATI SAMO JEDAN OD DVA FRAGMENTA KOJI SE POZIVA KADA JE VECI EKRAN, JER
            // NEMAJU ISTE ELEMNETE U SEBI, NITI ISTI IZGLED (VETRIKALNO, POSTOJI SPIENR KATEGORIJA I LIST VIEW KVIZOVA),
            // DOK U POLOŽENOM OBLIKU U TOM FRAGMENTU SE NALATI SAMO LIST VIEW KATEGORIJA (SA SVOJIM IKONAMA, DOK U VERIKALNOM
            // POLOZAJU U SPINERU KATEGORIJA NEMA IKONE KATEGORIJE)
            prviPutSeDobavljaSveIzBaze = true;
            napuniAtributeNaOsnovuStanjaUBazi(null); //u ovu fiju je bitno proslijediti kategoriju smao kada je sirok ekran

            spPostojeceKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
            lvKvizovi = (ListView) findViewById(R.id.lvKvizovi);

            reagujNaPovratakIzDodajKvizAkt();

            adapterSpinerKategorijaNaziv = new AdapterSpinerKategorijaNaziv(this, android.R.layout.simple_spinner_dropdown_item,
                    alSveKategorije, "Kategorije" );
            spPostojeceKategorije.setAdapter(adapterSpinerKategorijaNaziv);
            for(int i=0; i<alSveKategorije.size(); i++)
            {
                if(alSveKategorije.get(i).getNaziv().equals("Svi"))
                {
                    spPostojeceKategorije.setSelection(i);
                    break;
                }
            }
            spPostojeceKategorije.setPrompt("Kategorije");

            /* OVAKO SE NISTA NE MOZE PISATI, JER SE METODOM "setContentView" POSTAVLJA xml FAJL IZ "layout" DIREKTORIJA. NAKON TOGA,
                METODOMO "findViewById" MOZE PRISTUPATI SAMO ELEMNTIMA IZ LAYOUT-A POSTAVLJNJEOG PRETHODNO POMENUTOM METODOM, A INACE
                VRACA null

            footerViewText = (TextView) findViewById(R.id.footerText);
            footerViewText.setText(R.string.dodajKviz);*/
            footerView = getLayoutInflater().inflate(R.layout.footer_dodaj_kviz, null);
            lvKvizovi.addFooterView(footerView);

            footerView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v)
                {
                    Intent mojIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                    // u onClickListener-u na ListView parametar id=-1 za header i footer_dodaj_kviz bude -1, a position=0 za header, a
                    // za footer_dodaj_kviz postition = vel_liste ili position = vel_liste+1 ako u ima iznad liste vec header
                    mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                    mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);
                    mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);

                    mojIntent.putExtra("nacinRada", "dodavanjeKviza");

                    KvizoviAkt.this.startActivity(mojIntent);

                    return true;
                }
            });

            adapterKvizovi = new AdapterListaKvizova(this, R.layout.adapter_lista_s_ikonama, alFiltriraniKvizovi);
            lvKvizovi.setAdapter(adapterKvizovi);

            osvjeziAdaptereAkoJePovratakIzDodajKvizAkt();

            //Akcija koja se poduzima ako je selektovan neki elemenet spinnera
            spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                {
                    alFiltriraniKvizovi.clear();

                    //METODA "getSelectedItem" VRACA INSTANCU TIPA KATEGOIJRE, A NE TEKST
                    if(spPostojeceKategorije.getSelectedItem().equals(kategorijaSve))
                    {
                        dajSveKvizoveIzBaze();
                    }
                    else
                    {
                        Kategorija selektovanaKategorija = (Kategorija) spPostojeceKategorije.getSelectedItem();
                        dajSveKvizoveIzOdabraneKategorijeIzBaze(selektovanaKategorija);
                    }

                    adapterKvizovi.notifyDataSetChanged();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent)
                {
                    if(alSveKategorije.size() != 0)
                    {
                    }
                }
            });

            lvKvizovi.setLongClickable(true);
            lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int position, long id)
                {
                    Intent mojIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                    // u onClickListener-u na ListView parametar id=-1 za header i footer_dodaj_kviz bude -1, a position=0 za header, a
                    // za footer_dodaj_kviz postition = vel_liste ili position = vel_liste+1 ako u ima iznad liste vec header
                    mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                    mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);
                    mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);

                    //ako se ne posalje "odabraniKviz" kao kljuc, u sljedecem prozoru ce se pri provjeri tog kljuca
                    //sa metodom "getParcelExtra" vratiti se "null" vrijednost
                    if(id != -1 && position != alFiltriraniKvizovi.size())
                    {
                        //This is how you will pass a Serializable object
                        // using putExtra(String key, Serializable value) method
                        mojIntent.putExtra("odabraniKviz", alFiltriraniKvizovi.get(position));
                        mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", position);
                        mojIntent.putExtra("nacinRada", "editovanjeKviza");
                    }

                    KvizoviAkt.this.startActivity(mojIntent);

                    return true;
                }
            });

            lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener()
            {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {
                    Intent mojIntent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                    mojIntent.putExtra("odabraniKvizZaIgrati", alSviKvizovi.get(position));

                    KvizoviAkt.this.startActivity(mojIntent);
                }
            });
        }
    }

    private void dajSveKvizoveIzBaze()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null,this, intsDajSveKvizoveIzBaze.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);

        startService(mojIntent);
    }

    private void dajSveKvizoveIzOdabraneKategorijeIzBaze(Kategorija selektovanaKategorija)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajKvizoveIzOdabraneKategorije.class);
        mojIntent.putExtra("selektovanaKategorija", selektovanaKategorija);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        startService(mojIntent);
    }

    private void napuniAtributeNaOsnovuStanjaUBazi(Kategorija odabranaKategorija)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajSveKategorijeSveKvizoveSvaPitanja.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);

        //salje se samo u slucaju sirokog ekrana
        if(odabranaKategorija != null)
        mojIntent.putExtra("sirok ekran", odabranaKategorija);

        startService(mojIntent);
    }
    //sluzi za obradu informacija koje se vrate kroz intent servise
    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        switch (resultCode)
        {
            case intsDajSveKategorijeSveKvizoveSvaPitanja.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDajSveKategorijeSveKvizoveSvaPitanja.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */

                //AKO SE UCITAVAJU SVE INFORMACIJE IZ BAZE NA POCETKU RADA PROGRAMA
                if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeno sve iz baze"))
                {
                    alSveKategorije.clear();
                    alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    alSveKategorije.add(kategorijaSve);

                    alSviKvizovi.clear();
                    alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                    alSvaPitanja.clear();
                    alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));

                    if(sirina550 == false)
                    {
                        for(int i = 0; i < alSveKategorije.size(); i++)
                        {
                            if(alSveKategorije.get(i).getNaziv().equals("Svi"))
                            {
                                spPostojeceKategorije.setSelection(i);
                                break;
                            }
                        }
                        adapterSpinerKategorijaNaziv.notifyDataSetChanged();
                        adapterKvizovi.notifyDataSetChanged();
                    }
                    else if(resultData.getSerializable("sirok ekran") != null)
                    {
                        Kategorija odabranaKategorija = (Kategorija) resultData.getSerializable("sirok ekran");
                        dajSveKvizoveIzOdabraneKategorijeIzBaze(odabranaKategorija);
                    }
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeni kvizovi iz kategorije"))
                {
                    //AKO SE UCITAVAJU KVIZOVI IZ SELEKTOVANE KATEGORIJE

                    ArrayList<Kviz> sviKvizoviIzBazeIzSelektovaneKategorije = (ArrayList<Kviz>) resultData.getSerializable("kvizoviIzOdabraneKategorije");
                    ArrayList<Pitanje> pitanjaIzKvizovaIzKategorije = (ArrayList<Pitanje>) resultData.getSerializable("svaPitanjaIzKvizovaIzKategorije");

                    alFiltriraniKvizovi.clear();
                    alFiltriraniKvizovi.addAll(sviKvizoviIzBazeIzSelektovaneKategorije);
                    //dodavanje kvizova lokalno, iz selektovane kategorije, kojih ima u bazi, a nema lokalno
                    for(int i=0; i < sviKvizoviIzBazeIzSelektovaneKategorije.size(); i++)
                    {
                        boolean dodajKviz = true;
                        for(int j=0; j < alSviKvizovi.size(); j++)
                        {
                            if(sviKvizoviIzBazeIzSelektovaneKategorije.get(i).getNaziv().equals(alSviKvizovi.get(j).getNaziv()))
                            {
                                dodajKviz = false;
                                break;
                            }
                        }

                        if(dodajKviz == true)
                        {
                            alSviKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                            alFiltriraniKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                        }
                    }

                    //dodavanje pitanja koji ne postoje lokalno, iz dobavlejnih kvizova su, a ima ih u bazi
                    for(int i=0; i < pitanjaIzKvizovaIzKategorije.size(); i++)
                    {
                        boolean dodajPitanje = true;
                        for(int j=0; j < alSvaPitanja.size(); j++)
                        {
                            if(pitanjaIzKvizovaIzKategorije.get(i).getNaziv().equals(alSvaPitanja.get(j).getNaziv()))
                            {
                                dodajPitanje = false;
                                break;
                            }
                        }

                        if(dodajPitanje == true)
                            alSviKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                    }

                    if(sirina550 == false)
                    adapterKvizovi.notifyDataSetChanged();
                    else
                    {
                        DetailFrag detailFrag = new DetailFrag();

                        Bundle proslijedi = new Bundle();
                        proslijedi.putSerializable("sveKategorije",alSveKategorije);
                        proslijedi.putSerializable("sviKvizovi", alSviKvizovi);
                        proslijedi.putSerializable("svaPitanja", alSvaPitanja);
                        Kategorija selektovanaKategorija = (Kategorija) resultData.getSerializable("selektovana kategorija");
                        proslijedi.putSerializable("selektovana kategorija", selektovanaKategorija);

                        detailFrag.setArguments(proslijedi);
                        getFragmentManager().beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
                    }
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeni svi kvizovi iz baze"))
                {
                    //ovo je skljucivo dodatno da se ne bi ova lista dva puta azurirala pri porketanju
                    if(prviPutSeDobavljaSveIzBaze == false)
                    {
                        alSviKvizovi.clear();
                        alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                        alFiltriraniKvizovi.addAll(alSviKvizovi);
                    }
                    else
                        prviPutSeDobavljaSveIzBaze = false;

                }

                if(sirina550 == false)
                {
                    adapterSpinerKategorijaNaziv.notifyDataSetChanged();
                    adapterKvizovi.notifyDataSetChanged();
                }

                break;
            case intsDajSveKategorijeSveKvizoveSvaPitanja.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                if(resultData.getString("zadatak") != null &&
                    resultData.get("zadatak").equals("nema kolekcije neke u bazi"))
                {
                    if(resultData.getSerializable("alSveKategorije") != null)
                    {
                        alSveKategorije.clear();
                        alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    }

                    if(resultData.getSerializable("alSviKvizovi") != null)
                    {
                        alSviKvizovi.clear();
                        alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));
                    }

                    if(resultData.getSerializable("alSvaPitanja") != null)
                    {
                        alSvaPitanja.clear();
                        alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                    }
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kvizova u bazi"))
                {
                    Log.d("NEMA KVIZOVA U BAZI", "jos nije dodatn nijedan kviz u bazu");
                }

                break;
        }
    }

    private boolean jeLiPovratakIzKviza()
    {
        if(getIntent().getStringExtra("razlogPovratka") == null)
            return false;

        return true;
    }

    private void reagujNaPovratakIzDodajKvizAkt()
    {
        if(getIntent().getStringExtra("razlogPovratka") != null)
        {
            alSveKategorije.clear();
            alSvaPitanja.clear();

            alSveKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("sveKategorije");
            alSvaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("svaPitanja");

            int pozicijaKategorijeSvi = alSveKategorije.size()-1;
            for(int i=0; i<alSveKategorije.size(); i++)
            {
                if(alSveKategorije.get(i).getNaziv().equals("Svi"))
                {
                    pozicijaKategorijeSvi = i;
                    break;
                }
            }
            Collections.swap(alSveKategorije, pozicijaKategorijeSvi, alSveKategorije.size()-1);
        }

        // mojIntent.putExtra("razlogPovratka", "promjenaKviza");
        if(getIntent().getStringExtra("razlogPovratka") != null &&
                getIntent().getStringExtra("razlogPovratka").equals("promjenaKviza"))
        {
            alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizoviIPromjenjeni");
        }
        else if(getIntent().getStringExtra("razlogPovratka") != null &&
                getIntent().getStringExtra("razlogPovratka").equals("dodavanjeKviza"))
        {
            alSviKvizovi.clear();
            alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizoviIDodani");
        }
        else if (getIntent().getStringExtra("razlogPovratka") != null &&
                getIntent().getStringExtra("razlogPovratka").equals("dodavanjeKategorijeBezKviza"))
        {
            alSviKvizovi.clear();
            alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");
        }
    }

    private void osvjeziAdaptereAkoJePovratakIzDodajKvizAkt()
    {
        if(getIntent().getStringExtra("razlogPovratka") != null)
        {
            adapterSpinerKategorijaNaziv.notifyDataSetChanged();
            adapterKvizovi.notifyDataSetChanged();
        }
        else if(getIntent().getSerializableExtra("refresujKategorije") != null)
        {
            adapterSpinerKategorijaNaziv.notifyDataSetChanged();
        }
    }

    public void napuni()
    {
        /*alSveKategorije.add(new Kategorija("Biologija", "990"));
        alSveKategorije.add(new Kategorija("Hemija", "130"));
        alSveKategorije.add(new Kategorija("Historija", "1"));
        alSveKategorije.add(new Kategorija("Bosanski", "2"));
        alSveKategorije.add(new Kategorija("Matematika", "3"));
        alSveKategorije.add(new Kategorija("Njemacki", "4"));
        alSveKategorije.add(new Kategorija("Tjlesno", "5"));
        alSveKategorije.add(new Kategorija("Likovno", "6"));

        ArrayList<String> alOdg = new ArrayList<>();
        alOdg.add("prvi odg");
        alOdg.add("drugi odg");
        alOdg.add("treci odg");
        alOdg.add("cetvrti odg");
        alOdg.add("peti odg");
        alSvaPitanja.add(new Pitanje("prvo pitanje", "tekst prvog" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("drugo pitanje", "tekst drugog" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("trece pitanje", "tekst treci" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("cetvrto pitanje", "tekst cetvrti" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("peto pitanje", "tekst peti" , alOdg, "prvi odg"));

        ArrayList<Pitanje> prviKvizPitanja = new ArrayList<>();
        prviKvizPitanja.add(new Pitanje("kv1 prvo pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 drugo pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 trece pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 cetvrto pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 peto pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 sesto pitanje", "tekst prvog" , alOdg, "prvi odg"));

        alSvaPitanja.addAll(prviKvizPitanja);

        alSviKvizovi.add(new Kviz("prvi kviz bio" , prviKvizPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("drugi kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("treci kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("cetvrti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("peti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sedmi kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("osmi kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("deveti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("deseti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("jedanaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("dvanaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("trinaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("cetrnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("petnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sesnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sedamnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));

        alSviKvizovi.add(new Kviz("prvi kviz hemija" , alSvaPitanja, new Kategorija("Hemija", "130")));
        alSviKvizovi.add(new Kviz("drugi kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("treci kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("cetvrti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("peti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("sesti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("sedmi kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("osmi kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("deveti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("deseti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));*/


        ArrayList<Kategorija> pocetneKategorije = new ArrayList<>();
        ArrayList<Kviz> pocetniKvizovi = new ArrayList<>();
        ArrayList<Pitanje> pocetnaPitanja = new ArrayList<>();

        //KATEGORIJA
        Kategorija kategorija1 = new Kategorija();
        kategorija1.setNaziv("kategorija1");
        kategorija1.setId("1");

        Kategorija kategorija2 = new Kategorija();
        kategorija2.setNaziv("kategorija2");
        kategorija2.setId("2");

        pocetneKategorije.add(kategorija1);
        pocetneKategorije.add(kategorija2);

        //PITANJE
        Pitanje pitanje5 = new Pitanje();
        pitanje5.setNaziv("pitanje5");
        ArrayList<String> odgovori = new ArrayList<>();
        for(int i = 0; i<4; i++)
        {
            odgovori.add("ne"+String.valueOf(i));
        }
        odgovori.add("da");
        pitanje5.setOdgovori(odgovori);
        pitanje5.setTacan("da");
        pitanje5.setTekstPitanja(pitanje5.getNaziv());
        //drugo pitanje
        Pitanje pitanje6 = new Pitanje();
        pitanje6.setNaziv("pitanje6");
        ArrayList<String> odgovori2 = new ArrayList<>();
        for(int i = 0; i<4; i++)
        {
            odgovori2.add("ne"+String.valueOf(i));
        }
        odgovori2.add("da");
        pitanje6.setOdgovori(odgovori2);
        pitanje6.setTacan("da");
        pitanje6.setTekstPitanja(pitanje6.getNaziv());
        //trece pitanje
        Pitanje pitanje7 = new Pitanje();
        pitanje7.setNaziv("pitanje7");
        ArrayList<String> odgovori3 = new ArrayList<>();
        for(int i = 0; i<4; i++)
        {
            odgovori3.add("ne"+String.valueOf(i));
        }
        odgovori3.add("da");
        pitanje7.setOdgovori(odgovori3);
        pitanje7.setTacan("da");
        pitanje7.setTekstPitanja(pitanje7.getNaziv());

        pocetnaPitanja.add(pitanje5);
        pocetnaPitanja.add(pitanje6);
        pocetnaPitanja.add(pitanje7);
        //KVIZ
        Kviz kviz1 = new Kviz();
        kviz1.setNaziv("kviz1");
        kviz1.setKategorija(kategorija1);
        kviz1.getPitanja().add(pitanje5);

        Kviz kviz2 = new Kviz();
        kviz2.setNaziv("kviz2");
        kviz2.setKategorija(kategorija2);
        kviz2.getPitanja().add(pitanje5);
        kviz2.getPitanja().add(pitanje6);

        pocetniKvizovi.add(kviz1);
        pocetniKvizovi.add(kviz2);

        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsNapuniBazuPocetnimVrijednostima.class);
        mojIntent.putExtra("pocetneKategorije", pocetneKategorije);
        mojIntent.putExtra("pocetniKvizovi", pocetniKvizovi);
        mojIntent.putExtra("pocetnaPitanja", pocetnaPitanja);
        startService(mojIntent);
    }

    @Override
    public void klikNaKategoriju(Kategorija odabranaKategorija)
    {
        napuniAtributeNaOsnovuStanjaUBazi(odabranaKategorija);

        /*
        //PREBACENO U ON RESULT RECIEVED
        DetailFrag detailFrag = new DetailFrag();

        Bundle proslijedi = new Bundle();
        proslijedi.putSerializable("kategorijaSve",alSveKategorije);
        proslijedi.putSerializable("sviKvizovi", alSviKvizovi);
        proslijedi.putSerializable("svaPitanja", alSvaPitanja);

        detailFrag.setArguments(proslijedi);
        getFragmentManager().beginTransaction().replace(R.id.detailPlace, detailFrag).commit();*/
    }

    @Override
    public void onBackPressed()
    {
        moveTaskToBack(true);
    }
}
