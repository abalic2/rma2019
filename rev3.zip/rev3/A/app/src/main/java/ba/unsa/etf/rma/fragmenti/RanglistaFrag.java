package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.Fragment;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.AdapterListaKategorija;
import ba.unsa.etf.rma.adapteri.AdapterRanglista;
import ba.unsa.etf.rma.klase.Kviz;

public class RanglistaFrag extends Fragment
{
    //ATRIBUTI
    private ListView lvRanglista;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ranglista, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);

        lvRanglista = (ListView) getView().findViewById(R.id.ranglista);

        //OVDJE HVATAM PROSLIJEDJENE ARGUMENTE
        if(getArguments().containsKey("ranglista") == true)
        {
            ArrayList<Pair<String, Double>> alRanglista  = ( ArrayList<Pair<String, Double>>) getArguments().getSerializable("ranglista");

            AdapterRanglista adapterRanglista = new AdapterRanglista(getActivity(), R.layout.adapter_ranglista, alRanglista);
            lvRanglista.setAdapter(adapterRanglista);
        }
    }
}
