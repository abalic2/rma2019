package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.intentSevisi.intsDobaviUMogucaPitanjaIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsDodajOstvareniRezultatURangListuIPrikaziJeZaTajKviz;
import ba.unsa.etf.rma.intentSevisi.intsEditujKvizIzBaze;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

//fragment u kojem se prikazuju informacije (prosijek tacno odgovorenih, preostalo za odgogovoriti pitanja...) o kvizu koji se trnuetno igra
public class InformacijeFrag extends Fragment
{
    //ATRIBUTI
    TextView infNazivKviza;
    TextView infBrojTacnihPitanja;
    TextView infBrojPreostalihPitanja;
    TextView infProcenatTacni;
    Button btnKraj;

    Kviz kvizKojiSeIgra;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_informacije, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);

        infNazivKviza = (TextView) getView().findViewById(R.id.infNazivKviza);
        infBrojTacnihPitanja = (TextView) getView().findViewById(R.id.infBrojTacnihPitanja);
        infBrojPreostalihPitanja = (TextView) getView().findViewById(R.id.infBrojPreostalihPitanja);
        infProcenatTacni = (TextView) getView().findViewById(R.id.infProcenatTacni);
        btnKraj = (Button) getView().findViewById(R.id.btnKraj);

        btnKraj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                getActivity().finish();
            }
        });

        //OVDJE HVATAM PROSLIJEDJENE ARGUMENTE
        if(getArguments().containsKey("odabraniKvizKojiSeIgra") == true && getArguments().containsKey("brojPostavljenjih") == true
                && getArguments().containsKey("brojTacnoOdgovorenih") == true)
        {
            kvizKojiSeIgra = (Kviz) getArguments().getSerializable("odabraniKvizKojiSeIgra");

            int brojPostavljenihPitanja = Integer.parseInt(getArguments().getString("brojPostavljenjih"));

            infNazivKviza.setText(kvizKojiSeIgra.getNaziv());
            infBrojTacnihPitanja.setText(getArguments().getString("brojTacnoOdgovorenih"));

            if(getArguments().containsKey("zadnjePitanje") != true && kvizKojiSeIgra.getPitanja().size()>0)
            infBrojPreostalihPitanja.setText( String.valueOf(kvizKojiSeIgra.getPitanja().size()- brojPostavljenihPitanja-1) );
            else
                infBrojPreostalihPitanja.setText("0");

            if(brojPostavljenihPitanja > 0)
            {
                double procenat = Double.parseDouble(infBrojTacnihPitanja.getText().toString().trim()) / brojPostavljenihPitanja;

                infProcenatTacni.setText(String.valueOf(procenat));
            }
        }
    }
}
