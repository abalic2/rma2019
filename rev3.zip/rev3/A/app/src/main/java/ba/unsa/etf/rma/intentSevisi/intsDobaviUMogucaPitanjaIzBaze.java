package ba.unsa.etf.rma.intentSevisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class intsDobaviUMogucaPitanjaIzBaze extends IntentService
{
    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public intsDobaviUMogucaPitanjaIzBaze()
    {
        super(null);
    }

    public intsDobaviUMogucaPitanjaIzBaze(String name)
    {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        // Kod koji se nalazi ovdje će se izvršavati u posebnoj niti
        // Ovdje treba da se nalazi funkcionalnost servisa koja je
        // vremenski zahtjevna

        //STAVLJA SE OBICNI RESULT RECIEVER, A NE ONAJ KOJEG SI NAPISAO DA JE IZVEDEN IZ KLASE ResultReciever
        final ResultReceiver resultReceiver = intent.getParcelableExtra("risiver");

        ArrayList<Pitanje> alDodanaPitanja = (ArrayList<Pitanje>) intent.getSerializableExtra("listaDodanihPitanja");
        Kviz trenutniKviz = (Kviz) intent.getSerializableExtra("kvizIzKojegSuPitanja");

        boolean tekSeDodajeKviz = false;
        if(trenutniKviz == null)
            tekSeDodajeKviz = true;

        String token = null;

        try
        {
            token = dajToken();

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Pitanja";

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            ///govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);

            JSONObject jsonObject = new JSONObject(rezultat);
            JSONArray documents = jsonObject.getJSONArray("documents");

            ArrayList<Pitanje> alMogucaPitanja = new ArrayList<>();

            //DA OVO NE BI BACILO IZUZETAK, MORAJU PRAVILNO BITI UPISANI KVIZOVI
            for(int i=0; i<documents.length(); i++)
            {
                Pitanje pitanje = new Pitanje();

                JSONObject jedanDokument = documents.getJSONObject(i);

                JSONObject fields = jedanDokument.getJSONObject("fields");

                JSONObject naziv = fields.getJSONObject("naziv");
                pitanje.setNaziv(naziv.getString("stringValue"));
                pitanje.setTekstPitanja(pitanje.getNaziv()); //ovo je zbog uslova sa formua da je tekst pitanja isto sto i njegov naziv

                JSONObject indexTacnog = fields.getJSONObject("indexTacnog");
                int intIndexTacnog = indexTacnog.getInt("integerValue");

                JSONObject odgovori = fields.getJSONObject("odgovori");
                JSONObject arrayValue = odgovori.getJSONObject("arrayValue");
                JSONArray values = arrayValue.getJSONArray("values");

                ArrayList<String> odgovoriNaPitanje = new ArrayList<>();
                for(int j=0; j<values.length(); j++)
                {
                    JSONObject jsonJedanOdgovor = values.getJSONObject(j);
                    String stringOdogovr = jsonJedanOdgovor.getString("stringValue");

                    odgovoriNaPitanje.add(stringOdogovr);
                }
                pitanje.setOdgovori(odgovoriNaPitanje);
                pitanje.setTacan(pitanje.getOdgovori().get(intIndexTacnog));

                boolean dodajPitanje = true;
                for(int j=0; j<alDodanaPitanja.size(); j++)
                {
                    if(pitanje.getNaziv().equals(alDodanaPitanja.get(j).getNaziv()))
                    {
                        dodajPitanje = false;
                        break;
                    }
                }

                if(dodajPitanje == true)
                    alMogucaPitanja.add(pitanje);
            }

            Bundle bundle = new Bundle();
            bundle.putSerializable("mogucaPitanjaIzBaze", alMogucaPitanja);
            resultReceiver.send(STATUS_FINISHED,bundle);
        }
        catch (IOException e)
        {
            e.printStackTrace();

            Bundle bundle = new Bundle();
            bundle.putString(Intent.EXTRA_TEXT, e.toString());
            resultReceiver.send(STATUS_ERROR, bundle);
        }
        catch (JSONException e)
        {
            e.printStackTrace();

            Bundle bundle = new Bundle();
            bundle.putString(Intent.EXTRA_TEXT, e.toString());
            resultReceiver.send(STATUS_ERROR, bundle);
        }

    }

    public String dajToken()
    {
        String token = null;

        try
        {
            InputStream is = getBaseContext().getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = null;
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            token = credentials.getAccessToken();

            is.close();
            //Log.d("TOKEN", token);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return token;
    }

    public String convertStreamToString(InputStream is)
    {
        //BufferedReader je klasa wrapper za oboje "InputStreamReader/FileReader". Koristeci bufffer(spremink), efikasnije odradjuje citanje bajta(tj. charova, jer je jedan char jena bajt)
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        //String is immutable, if you try to alter their values, another object gets created, whereas StringBuffer and StringBuilder are mutable so they can change their values.
        // Thread-Safety Difference: The difference between StringBuffer and StringBuilder is that StringBuffer is thread-safe.
        StringBuilder sb = new StringBuilder();
        String line = null;
        try
        {
            while ((line = reader.readLine()) != null)
                sb.append(line + "\n");
        }
        catch (IOException e)
        {
            e.getStackTrace();
        }
        finally
        {
            try
            {
                is.close();
            }
            catch (IOException e)
            {
                e.getStackTrace();
            }
        }

        return sb.toString();
    }
}

