package ba.unsa.etf.rma.intentSevisi;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class intsNapuniBazuPocetnimVrijednostima extends IntentService
{
    public intsNapuniBazuPocetnimVrijednostima()
    {
        super(null);
    }

    public intsNapuniBazuPocetnimVrijednostima(String name)
    {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        // Kod koji se nalazi ovdje će se izvršavati u posebnoj niti
        // Ovdje treba da se nalazi funkcionalnost servisa koja je
        // vremenski zahtjevna

        ArrayList<Kategorija> alSveKategorije = (ArrayList<Kategorija>) intent.getSerializableExtra("pocetneKategorije");
        boolean uspjesnoUpisaneSveKategorije = false;
        ArrayList<Kviz> alSviKvizovi = (ArrayList<Kviz>) intent.getSerializableExtra("pocetniKvizovi");
        boolean uspjesnoUpisaniSviKvizovi = false;
        ArrayList<Pitanje> alSvaPitanja = (ArrayList<Pitanje>) intent.getSerializableExtra("pocetnaPitanja");
        boolean uspjesnoUpisanaSvaPitanja = false;

        String token = null;
        token = dajToken();

        //UPISIVANJE SVIH KATEGORIJA U BAZU NA POCETKU RADA APLIKACIJE-------------------------------------------
        try
        {
            for(int i = 0; i < alSveKategorije.size(); i++)
            {
                String spojenoIme = URLEncoder.encode(alSveKategorije.get(i).getNaziv(), "utf-8");

                String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kategorije?documentId=KATEGORIJA" + spojenoIme;

                URL urlObjekat = new URL(url);

                HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                konekcija.setRequestProperty("Authorization", "Bearer " + token);

                //govori koju akciju vrsimo
                konekcija.setRequestMethod("POST");
                //govori u kojem formatu upisujemo u bazu
                konekcija.setRequestProperty("Content-Type", "appliction/json");
                //namjesta da se: prihvati response i format u kojem se prihvata
                konekcija.setRequestProperty("Accept", "appliation/json");

                String dokuemnt = "{ \"fields\": " +
                        "{ \"naziv\": { \"stringValue\": \"" + alSveKategorije.get(i).getNaziv() + "\"}, " +
                        "  \"idIkonice\": { \"integerValue\":\"" + alSveKategorije.get(i).getId() + "\"} " +
                        "}}";

                if(daLiVecPostojiKategorijaUBazi(alSveKategorije.get(i), token) == false)
                {
                    OutputStream outputStream = konekcija.getOutputStream();
                    byte[] unos = dokuemnt.getBytes();
                    outputStream.write(unos, 0, unos.length);

                    InputStream odgovor = konekcija.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = bufferedReader.readLine()) != null)
                        response.append(responseLine.trim());

                    Log.d("DODANA KATEGORIJA", response.toString());
                }
            }
            uspjesnoUpisaneSveKategorije = true;
        }
        catch (ProtocolException e1)
        {
            e1.printStackTrace();
        }
        catch (MalformedURLException e1)
        {
            e1.printStackTrace();
        }
        catch (IOException e1)
        {
            e1.printStackTrace();
        }

        //UPISIVANJE SVIH KATEGORIJA U BAZU NA POCETKU RADA APLIKACIJE-------------------------------------------
        if(uspjesnoUpisaneSveKategorije == true)
            try
            {
                for(int i = 0; i < alSvaPitanja.size(); i++)
                {
                    String spojenoIme = URLEncoder.encode(alSvaPitanja.get(i).getNaziv(), "utf-8");

                    String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Pitanja?documentId=PITANJE"+spojenoIme;

                    URL urlObjekat = new URL(url);

                    HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                    konekcija.setRequestProperty("Authorization", "Bearer "+token);

                    //govori koju akciju vrsimo
                    konekcija.setRequestMethod("POST");
                    //govori u kojem formatu upisujemo u bazu
                    konekcija.setRequestProperty("Content-Type", "appliction/json");
                    //namjesta da se: prihvati response i format u kojem se prihvata
                    konekcija.setRequestProperty("Accept", "appliation/json");

                    int indeksTacnog = -1; //nikad nece ostati -1 ako je dio koda koji je prethodio ovome tacno odradjen
                    for(int j=0; j<alSvaPitanja.get(i).getOdgovori().size(); j++)
                    {
                        // "i" je za lociranje clana niza svih pitanja, a "j" za redni broj odgovora u tom pitanju
                        if(alSvaPitanja.get(i).getTacan().equals(alSvaPitanja.get(i).getOdgovori().get(j)))
                        {
                            indeksTacnog = j;
                            break;
                        }
                    }

                    StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                            "{ \"naziv\": { \"stringValue\": \""+alSvaPitanja.get(i).getNaziv()+"\"}, " +
                            "  \"indexTacnog\": { \"integerValue\":\""+indeksTacnog+"\"}, " +
                            " \"odgovori\" : { \"arrayValue\" : { \"values\" : [");
                    for(int j=0; j<alSvaPitanja.get(i).getOdgovori().size(); j++)
                    {
                        String jedanOdgovor = " { \"stringValue\": \""+alSvaPitanja.get(i).getOdgovori().get(j)+"\"}";
                        dokuemntBilder.append(jedanOdgovor);

                        if(j+1 != alSvaPitanja.get(i).getOdgovori().size())
                            dokuemntBilder.append(", ");
                    }
                    dokuemntBilder.append("]}} }}");

                    String dokuemnt = dokuemntBilder.toString();

                    if(daLiVecPostojiPitanjeUBazi(alSvaPitanja.get(i), token) == false)
                    {
                        OutputStream outputStream = konekcija.getOutputStream();
                        byte[] unos = dokuemnt.getBytes();
                        outputStream.write(unos, 0, unos.length);

                        InputStream odgovor = konekcija.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while((responseLine = bufferedReader.readLine()) != null)
                            response.append(responseLine.trim());

                        Log.d("DODATO PITANJE", response.toString());
                    }
                }

                uspjesnoUpisanaSvaPitanja = true;
            }
            catch (UnsupportedEncodingException e)
            {
                e.printStackTrace();
            }
            catch (ProtocolException e)
            {
                e.printStackTrace();
            }
            catch (MalformedURLException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

        //UPISIVANJE SVIH KVIZOVA U BAZU NA POCETKU RADA APLIKACIJE-------------------------------------------
        if(uspjesnoUpisaneSveKategorije == true && uspjesnoUpisanaSvaPitanja == true)
            try
            {
                for(int i = 0; i < alSviKvizovi.size(); i++)
                {
                    if(daLiVecPostojiKvizUBazi(alSviKvizovi.get(i), token) == true)
                        continue;

                    String spojenoIme = URLEncoder.encode(alSviKvizovi.get(i).getNaziv(), "utf-8");

                    String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi?documentId=KVIZ"+spojenoIme;

                    URL urlObjekat = new URL(url);

                    HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                    konekcija.setRequestProperty("Authorization", "Bearer "+token);

                    //govori koju akciju vrsimo
                    konekcija.setRequestMethod("POST");
                    //govori u kojem formatu upisujemo u bazu
                    konekcija.setRequestProperty("Content-Type", "appliction/json");
                    //namjesta da se: prihvati response i format u kojem se prihvata
                    konekcija.setRequestProperty("Accept", "appliation/json");

                    if(daLiVecPostojiKategorijaUBazi(alSviKvizovi.get(i).getKategorija(), token))
                    upisiKategorijuAkoNePostojiUBazi(alSviKvizovi.get(i).getKategorija(), token);

                    StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                            "{ \"naziv\": { \"stringValue\": \""+alSviKvizovi.get(i).getNaziv()+"\"}, " +
                            "  \"idKategorije\": { \"stringValue\":\"KATEGORIJA"+alSviKvizovi.get(i).getKategorija().getNaziv()+"\"}, " +
                            " \"pitanja\" : { \"arrayValue\" : { \"values\" : [");
                    for(int j = 0; j < alSviKvizovi.get(i).getPitanja().size(); j++)
                    {
                        if(daLiVecPostojiPitanjeUBazi(alSviKvizovi.get(i).getPitanja().get(j), token) == false)
                            dodajPitanjeUBazu(alSviKvizovi.get(i).getPitanja().get(j), token);

                        String IDubacenogPitanja = "PITANJE"+alSviKvizovi.get(i).getPitanja().get(j).getNaziv();
                        String jednoPitanje = " { \"stringValue\": \""+IDubacenogPitanja+"\"}";

                        dokuemntBilder.append(jednoPitanje);
                        if(j+1 != alSviKvizovi.get(i).getPitanja().size())
                            dokuemntBilder.append(", ");
                    }
                    dokuemntBilder.append("]}} }}");

                    String dokument = dokuemntBilder.toString();

                    OutputStream outputStream = konekcija.getOutputStream();
                    byte[] unos = dokument.getBytes();
                    outputStream.write(unos, 0, unos.length);

                    InputStream odgovor = konekcija.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = bufferedReader.readLine()) != null)
                        response.append(responseLine.trim());

                    Log.d("DODANI KVIZ", response.toString());
                }

                uspjesnoUpisaniSviKvizovi = true;
            }
            catch (UnsupportedEncodingException e)
            {
                e.printStackTrace();
            }
            catch (ProtocolException e)
            {
                e.printStackTrace();
            }
            catch (MalformedURLException e)
            {
                e.printStackTrace();
            }
            catch (IOException e)
            {
                e.printStackTrace();
                uspjesnoUpisaniSviKvizovi = false;
            }

    }

    private boolean daLiVecPostojiKvizUBazi(Kviz kviz, String token)
    {
        try
        {
            String spojenoIme = URLEncoder.encode(kviz.getNaziv(), "utf-8");

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi/KVIZ"+spojenoIme;
            URL urlObjekat = null;

            urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
        }
        catch (Exception e)
        {
            Log.d("NE POSTOJI KVIZ", "kviz\""+ kviz.getNaziv()+"\" koje se pokusava unijeti u bazu ne postoji u bazi");
            return false;
        }

        return true;
    }

    private boolean daLiVecPostojiPitanjeUBazi(Pitanje pitanje, String token)
    {
        //AKO PITANJE POSTOJI U BAZI, KONEKCIJA CE SE MOCI IZVRSITI, ALI AKO NE POSTJOI, NECE SE MOCI POVEZATI I BACIT CE NEKI IZAUZETAK
        try
        {
            String spojenoIme = URLEncoder.encode(pitanje.getNaziv(), "utf-8");

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Pitanja/PITANJE"+spojenoIme;
            URL urlObjekat = null;

            urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
        }
        catch (Exception e)
        {
            Log.d("NE POSTOJI PITANJE", "pitanje\""+ pitanje.getNaziv()+"\" koje se pokusava unijeti u bazu ne postoji u bazi");
            return false;
        }

        return true;
    }

    private void dodajPitanjeUBazu(Pitanje pitanje, String token)
    {
        try
        {
            String spojenoIme = URLEncoder.encode(pitanje.getNaziv(), "utf-8");

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Pitanja?documentId=PITANJE"+spojenoIme;

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("POST");
            //govori u kojem formatu upisujemo u bazu
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");

            int indeksTacnog = -1; //nikad nece ostati -1 ako je dio koda koji je prethodio ovome tacno odradjen
            for(int i = 0; i < pitanje.getOdgovori().size(); i++)
            {
                if(pitanje.getTacan().equals(pitanje.getOdgovori().get(i)))
                {
                    indeksTacnog = i;
                    break;
                }
            }

            StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                    "{ \"naziv\": { \"stringValue\": \""+pitanje.getNaziv()+"\"}, " +
                    "  \"indexTacnog\": { \"integerValue\":\""+indeksTacnog+"\"}, " +
                    " \"odgovori\" : { \"arrayValue\" : { \"values\" : [");
            for(int i = 0; i < pitanje.getOdgovori().size(); i++)
            {
                String jedanOdgovor = " { \"stringValue\": \""+pitanje.getOdgovori().get(i)+"\"}";
                dokuemntBilder.append(jedanOdgovor);

                if(i+1 != pitanje.getOdgovori().size())
                    dokuemntBilder.append(", ");
            }
            dokuemntBilder.append("]}} }}");

            String dokuemnt = dokuemntBilder.toString();

            OutputStream outputStream = konekcija.getOutputStream();
            byte[] unos = dokuemnt.getBytes();
            outputStream.write(unos, 0, unos.length);

            InputStream odgovor = konekcija.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while((responseLine = bufferedReader.readLine()) != null)
                response.append(responseLine.trim());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private void upisiKategorijuAkoNePostojiUBazi(Kategorija kategorija, String token)
    {
        try
        {
            String spojenoIme = URLEncoder.encode(kategorija.getNaziv(), "utf-8");

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kategorije?documentId=KATEGORIJA" + spojenoIme;
            URL urlObjekat = null;
            urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer " + token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("POST");
            //govori u kojem formatu upisujemo u bazu
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");

            String dokuemnt = "{ \"fields\": " +
                    "{ \"naziv\": { \"stringValue\": \"" + kategorija.getNaziv() + "\"}, " +
                    "  \"idIkonice\": { \"integerValue\":\"" + kategorija.getId() + "\"} " +
                    "}}";

            OutputStream outputStream = konekcija.getOutputStream();
            byte[] unos = dokuemnt.getBytes();
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch (ProtocolException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public boolean daLiVecPostojiKategorijaUBazi(Kategorija kategorijaKojaSeMozdaDodaje, String token)
    {
        //AKO KATEGORIJA POSTOJI U BAZI, KONEKCIJA CE SE MOCI IZVRSITI, ALI AKO NE POSTJOI, NECE SE MOCI POVEZATI, I BACIT CE NEKI IZAUZETAK
        try
        {
            String spojenoIme = URLEncoder.encode(kategorijaKojaSeMozdaDodaje.getNaziv(), "utf-8");
            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kategorije/KATEGORIJA"+spojenoIme;
            URL urlObjekat = null;

            urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
        }
        catch (Exception e)
        {
            Log.d("NE POSTOJI KATEGORIJA", "kategorija \""+ kategorijaKojaSeMozdaDodaje.getNaziv()+"\"koja se pokusava unijeti u bazu ne postoji u bazi");
            return false;
        }

        return  true;
    }

    public String dajToken()
    {
        String token = null;

        try
        {
            InputStream is = getBaseContext().getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = null;
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            token = credentials.getAccessToken();

            is.close();
            //Log.d("TOKEN", token);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return token;
    }

    public String convertStreamToString(InputStream is)
    {
        //BufferedReader je klasa wrapper za oboje "InputStreamReader/FileReader". Koristeci bufffer(spremink), efikasnije odradjuje citanje bajta(tj. charova, jer je jedan char jena bajt)
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        //String is immutable, if you try to alter their values, another object gets created, whereas StringBuffer and StringBuilder are mutable so they can change their values.
        // Thread-Safety Difference: The difference between StringBuffer and StringBuilder is that StringBuffer is thread-safe.
        StringBuilder sb = new StringBuilder();
        String line = null;
        try
        {
            while ((line = reader.readLine()) != null)
                sb.append(line + "\n");
        }
        catch (IOException e)
        {
            e.getStackTrace();
        }
        finally
        {
            try
            {
                is.close();
            }
            catch (IOException e)
            {
                e.getStackTrace();
            }
        }
        return sb.toString();
    }
}